@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py.exe >nul 2>&1
if errorlevel 1 goto use_python
py -3 update.py 
goto finish
:use_python
python update.py 
:finish
pause
