import ast, ctypes, hashlib, json, os, sys, tempfile
from pathlib import Path
from contextlib import contextmanager
from datetime import datetime

@contextmanager
def stopped_lock():
    handle = None
    if os.name == 'nt':
        k = ctypes.WinDLL('kernel32', use_last_error=True)
        k.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_bool, ctypes.c_wchar_p]
        k.CreateMutexW.restype = ctypes.c_void_p
        k.CloseHandle.argtypes = [ctypes.c_void_p]
        k.CloseHandle.restype = ctypes.c_bool
        handle = k.CreateMutexW(None, False, r'Local\ZanzaRemainingMaterialSystem')
        error = ctypes.get_last_error()
        if not handle:
            raise ctypes.WinError(error)
        if error == 183:
            k.CloseHandle(handle)
            raise ValueError('システムが稼働中です。05_step11_stop.batで停止してください')
    try:
        yield
    finally:
        if handle:
            k.CloseHandle(handle)

def ensure_stopped(folder):
    status=folder/'zanza_runtime_status.json'
    if status.exists():
        data=json.loads(status.read_text(encoding='utf-8-sig'))
        if data.get('status') == 'RUNNING':
            raise ValueError('状態がRUNNINGです。停止を確認してください。強制終了後は再起動して正常停止してください')

ROOT = Path(__file__).resolve().parent
APP_LEGACY = 'zanza_system_step11_countdown_popup_manual_capture.pyw'

def digest(data):
    return hashlib.sha256(data).hexdigest() if data is not None else None

def atomic(path, data):
    fd, name = tempfile.mkstemp(dir=str(path.parent))
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(name, path)
    finally:
        if os.path.exists(name): os.unlink(name)

def patch_source(source):
    if 'import manual_capture' in source: raise ValueError('Ctrl+F8確認撮影は適用済みです')
    funcs={n.name:n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef)}
    variants=json.loads((ROOT/'supported.json').read_text(encoding='utf-8'))
    match=any(all(name in funcs and ast.dump(funcs[name])==ast.dump(ast.parse(text).body[0]) for name,text in variant.items()) for variant in variants)
    if not match: raise ValueError('対応する本体と異なります。変更せず中止しました。現在の本体を確認してください')
    lines=source.splitlines(True)
    payload=(ROOT/'handlers.txt').read_text(encoding='utf-8')
    for name in sorted(('handle_manual_capture_async','on_manual_capture'),key=lambda n:funcs[n].lineno,reverse=True):
        n=funcs[name]; lines[n.lineno-1:n.end_lineno]=[payload+'\n' if name=='handle_manual_capture_async' else '']
    result=''.join(lines)
    anchor='            logging.info("[F12-FIX] ARMED lane=%s shelf=%s hwnd=%s wait=%s", lane_id, normalized, hwnd, LOCKOUT_SECONDS)'
    if result.count(anchor)!=1: raise ValueError('F12記憶処理の構成が異なります')
    result=result.replace(anchor,'            manual_capture.remember(SCRIPT_DIR, context, SPREADSHEET_URL, normalized)\n'+anchor)
    result='import manual_capture\n'+result
    ast.parse(result)
    return result

def operate(folder, restore=False):
    folder=Path(folder).resolve()
    with stopped_lock():
        ensure_stopped(folder)
        history=folder/'backup_ctrl_f8'
        if history.is_symlink(): raise ValueError('バックアップ先がリンクのため中止')
        if restore:
            records=sorted(history.glob('*/manifest.json'))
            if not records: raise ValueError('復元用バックアップがありません')
            record=records[-1];meta=json.loads(record.read_text(encoding='utf-8'))
            for name,item in meta.items():
                target=folder/name
                if target.is_symlink(): raise ValueError('リンクは復元できません')
                current=target.read_bytes() if target.exists() else None
                if digest(current) not in (item['before'],item['after']):raise ValueError('更新後に変更されたファイルがあります: '+name)
                saved=(record.parent/name).read_bytes() if item['before'] is not None else None
                if digest(saved)!=item['before']:raise ValueError('バックアップ不一致')
            for name,item in meta.items():
                if item['before'] is None:
                    (folder/name).unlink(missing_ok=True)
                else: atomic(folder/name,(record.parent/name).read_bytes())
            print('更新前へ戻しました。');return
        candidates=[n for n in ('zanza.pyw',APP_LEGACY) if (folder/n).is_file()]
        if len(candidates)!=1:raise ValueError('本体が1つ入った運用フォルダを指定してください')
        app=candidates[0];settings='settings.json' if app=='zanza.pyw' else 'zanza_step11_settings.json'
        names=[app,settings,'manual_capture.py']
        if any((folder/n).is_symlink() for n in names):raise ValueError('対象ファイルがリンクのため中止')
        before={n:(folder/n).read_bytes() if (folder/n).exists() else None for n in names}
        if before[settings] is None:raise ValueError('設定JSONがありません')
        if before['manual_capture.py'] is not None:raise ValueError('manual_capture.pyが既にあります。上書きせず中止します')
        data=json.loads(before[settings].decode('utf-8-sig'))
        data['manual_capture_hotkey']='ctrl+f8'
        data['manual_capture_suppress']=False
        after={app:patch_source(before[app].decode('utf-8-sig')).encode('utf-8-sig'), settings:(json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode('utf-8-sig'), 'manual_capture.py':(ROOT/'manual_capture.py').read_bytes()}
        backup=history/datetime.now().strftime('%Y%m%d_%H%M%S_%f');backup.mkdir(parents=True)
        for n,content in before.items():
            if content is not None:(backup/n).write_bytes(content)
        meta={n:{'before':digest(before[n]),'after':digest(after[n])} for n in names}
        (backup/'manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
        try:
            for n in names:
                current=(folder/n).read_bytes() if (folder/n).exists() else None
                if current!=before[n]:raise ValueError('処理中にファイルが変更されました')
                atomic(folder/n,after[n])
        except Exception:
            for n in names:
                if before[n] is None:(folder/n).unlink(missing_ok=True)
                else:atomic(folder/n,before[n])
            raise
        print('Ctrl+F8確認撮影に更新しました。変更した本体と設定、追加モジュール:')
        for n in names:print('  '+n)
        print('いつもの起動方法で再起動してください。')

if __name__=='__main__':
    try:
        args=sys.argv[1:];restore='--restore' in args;args=[x for x in args if x!='--restore']
        folder=args[0] if args else input('停止済みの運用フォルダを入力: ').strip().strip('"')
        if not folder:raise ValueError('フォルダが未指定です')
        operate(folder,restore)
    except Exception as error:
        print('中止: '+str(error));sys.exit(1)
