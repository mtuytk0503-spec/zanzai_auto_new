"""Shelf history and an isolated Tk confirmation window. Standard library only."""
import hashlib
import json
import logging
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import threading
import unicodedata
from datetime import datetime

_history_lock = threading.Lock()
dialog_lock = threading.Lock()


def normalize(value):
    value = unicodedata.normalize('NFKC', str(value)).strip()
    return value if re.fullmatch(r'[0-9]+-[0-9]+-[0-9]+', value) and len(value) <= 32 else ''


def history_key(context, spreadsheet):
    identity = [spreadsheet, context['lane_id'], context['sheet_name'], context['folder_id']]
    return hashlib.sha256(json.dumps(identity, ensure_ascii=False).encode()).hexdigest()


def previous(root, context, spreadsheet):
    try:
        with _history_lock:
            data = json.loads((Path(root) / 'last_shelves.json').read_text(encoding='utf-8'))
        item = data.get(history_key(context, spreadsheet), {})
        return normalize(item.get('shelf', '')), item.get('at', '')
    except FileNotFoundError:
        return '', ''
    except Exception:
        logging.exception('[MANUAL-F8] HISTORY_READ_ERROR')
        return '', ''


def remember(root, context, spreadsheet, shelf):
    shelf = normalize(shelf)
    if not shelf:
        return
    try:
        path = Path(root) / 'last_shelves.json'
        with _history_lock:
            if path.exists():
                data = json.loads(path.read_text(encoding='utf-8'))
            else:
                data = {}
            data[history_key(context, spreadsheet)] = {'shelf': shelf, 'at': datetime.now().strftime('%Y/%m/%d %H:%M:%S')}
            temp = path.with_suffix('.tmp')
            temp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
            temp.replace(path)
    except Exception:
        logging.exception('[MANUAL-F8] HISTORY_WRITE_ERROR')


def ask(root, lane, shelf, at, stop_event):
    # A separate process owns Tk. Existing notification windows keep their own event loop.
    with tempfile.TemporaryDirectory(prefix='zanza_manual_') as folder:
        request = Path(folder) / 'request.json'
        result = Path(folder) / 'result.json'
        request.write_text(json.dumps({'lane': lane, 'shelf': shelf, 'at': at}, ensure_ascii=False), encoding='utf-8')
        process = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), str(request), str(result)],
                                   creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0) if os.name == 'nt' else 0)
        try:
            while process.poll() is None:
                if stop_event.wait(.1):
                    process.terminate()
                    process.wait(timeout=5)
                    return None
            if process.returncode != 0:
                raise RuntimeError('確認画面を開けませんでした。Tkinterの環境を確認してください。')
            if not result.exists():
                return None
            return normalize(json.loads(result.read_text(encoding='utf-8')).get('shelf', '')) or None
        finally:
            if process.poll() is None:
                process.terminate()
                process.wait(timeout=5)


def show_dialog(request_path, result_path):
    import tkinter as tk
    data = json.loads(Path(request_path).read_text(encoding='utf-8'))
    root = tk.Tk()
    root.title('残材管理 — 棚番号を確認')
    root.resizable(False, False)
    root.attributes('-topmost', True)
    frame = tk.Frame(root, padx=28, pady=22)
    frame.pack()
    tk.Label(frame, text=data['lane'] + ' の手動撮影', font=('Yu Gothic UI', 24, 'bold')).pack(pady=(0, 10))
    shelf = normalize(data.get('shelf', ''))
    tk.Label(frame, text='前回の棚番号' if shelf else '初回です。棚番号を入力してください', font=('Yu Gothic UI', 14)).pack()
    label = tk.Label(frame, text=shelf or '未登録', font=('Yu Gothic UI', 32, 'bold'))
    label.pack(pady=8)
    tk.Label(frame, text='記憶日時：' + str(data.get('at') or '—'), font=('Yu Gothic UI', 11)).pack()
    tk.Label(frame, text='実際の棚番号と号機が合っているか確認してください', font=('Yu Gothic UI', 12)).pack(pady=8)
    editor = tk.Frame(frame)
    entries = []
    values = shelf.split('-') if shelf else ['', '', '']
    for index, value in enumerate(values):
        entry = tk.Entry(editor, width=5, justify='center', font=('Yu Gothic UI', 24))
        entry.grid(row=0, column=index * 2)
        entry.insert(0, value)
        entries.append(entry)
        if index < 2:
            tk.Label(editor, text='－', font=('Yu Gothic UI', 20)).grid(row=0, column=index * 2 + 1)
    error = tk.Label(frame, text='', fg='#b00020', font=('Yu Gothic UI', 12))
    error.pack()
    editing = [not bool(shelf)]

    def edit():
        editing[0] = True
        editor.pack(before=error, pady=10)
        capture.configure(text='入力した棚番号で撮影')
        entries[0].focus_set()
        entries[0].selection_range(0, 'end')

    def confirm():
        candidate = '-'.join(e.get().strip() for e in entries) if editing[0] else shelf
        candidate = normalize(candidate)
        if not candidate:
            error.configure(text='3つの欄に数字を入力してください')
            return
        Path(result_path).write_text(json.dumps({'shelf': candidate}), encoding='utf-8')
        root.destroy()

    capture = tk.Button(frame, text='この棚で撮影', command=confirm, font=('Yu Gothic UI', 20, 'bold'),
                        bg='#176b39', fg='white', width=23, pady=8)
    capture.pack(pady=10)
    tk.Button(frame, text='棚番号を変更', command=edit, font=('Yu Gothic UI', 16), width=26).pack(pady=4)
    tk.Button(frame, text='やめる', command=root.destroy, font=('Yu Gothic UI', 16), width=26).pack(pady=4)
    root.bind('<Escape>', lambda event: root.destroy())
    # Enter advances fields; photography always requires an explicit button click.
    for i, entry in enumerate(entries):
        entry.bind('<Return>', lambda event, i=i: (entries[i+1].focus_set() if i < 2 else capture.focus_set(), 'break')[-1])
    if not shelf:
        edit()
    root.update_idletasks()
    root.geometry('+%d+%d' % (max(0, (root.winfo_screenwidth()-root.winfo_width())//2), max(0, (root.winfo_screenheight()-root.winfo_height())//2)))
    root.lift()
    root.mainloop()


if __name__ == '__main__':
    show_dialog(sys.argv[1], sys.argv[2])
