import ast,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def patch_source(source):
    if 'import input_watch' in source:raise ValueError('今回の対策は適用済みです')
    if 'import manual_capture' not in source:raise ValueError('Ctrl+F8版を対象とした修正です')
    funcs={n.name:n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef)}
    expected=json.loads((ROOT/'expected.json').read_text())
    for name,text in expected.items():
        if name not in funcs or ast.dump(funcs[name])!=ast.dump(ast.parse(text).body[0]):raise ValueError('本体が検証済みの版と異なります: '+name)
    def replace(old,new):
        nonlocal source
        if source.count(old)!=1:raise ValueError('変更箇所を一意に確認できません: '+old[:60])
        source=source.replace(old,new,1)
    replace("        manual_capture.dialog_lock.release()", "        manual_capture.dialog_lock.release()\n        logging.info('[MANUAL-F8] LOCKS_RELEASED lane=%s', lane_id)")
    # Avoid popup warnings when the AS/400 page itself is outside the workflow.
    replace('        show_operator_popup(\'号機を選んでください\', \'撮影する号機のAS/400ウィンドウをクリックしてCtrl+F8を押してください\', level=\'warning\', duration=4.0)', '        # Targetless manual key: log only.')
    replace('    if popup:\n        show_operator_popup', '    if reason in {"NOT_LANE", "SCREEN_REJECTED", "FOCUS_CHANGED", "OCR_FOCUS_CHANGED", "NO_WINDOW_ID"}:\n        return\n    if popup:\n        show_operator_popup')
    replace('    if not OPERATOR_POPUP_ENABLED:\n        return\n\n    if duration is None:', '''    if not OPERATOR_POPUP_ENABLED:
        return
    gate = globals().get('_popup_gate')
    if gate is None or not gate.allowed():
        return
    context = _get_active_lane_context()
    if context is None:
        return
    import re as _re
    mentioned = set(_re.findall(r'[0-9]+号', str(message)))
    if mentioned and context['lane_id'] not in mentioned:
        return

    if duration is None:''')
    replace('        "title": str(title or ""),','        "window_hwnd": context["window"]._hWnd,\n        "title": str(title or ""),')
    replace('        hide_at = 0.0\n\n        def apply_no_activate_style():','        hide_at = 0.0\n        visible_hwnd = None\n\n        def apply_no_activate_style():')
    replace('        def show_item(item):\n            nonlocal hide_at','''        def show_item(item):
            nonlocal hide_at, visible_hwnd
            if not _popup_gate.allowed(item.get('window_hwnd')):
                root.withdraw()
                hide_at = 0.0
                return
            visible_hwnd = item.get('window_hwnd')''')
    replace('            elif hide_at and time.time() >= hide_at:', '            elif hide_at and (time.time() >= hide_at or not _popup_gate.allowed(visible_hwnd)):')
    replace("panel_thread = threading.Thread(target=_step12_panel_worker, name='step12-panel', daemon=True)", "_popup_gate = input_watch.PopupGate(_get_active_lane_context, is_target_screen, retry_stop_event)\n_popup_gate.start()\n\npanel_thread = threading.Thread(target=_step12_panel_worker, name='step12-panel', daemon=True)")
    a=source.index("keyboard.add_hotkey('f12', on_f12)")
    b=source.index('logging.info("==============================================")',a)
    source=source[:a]+'''if MANUAL_CAPTURE_HOTKEY.replace(' ', '').lower() != 'ctrl+f8':
    raise RuntimeError('今回の入力監視はCtrl+F8専用です。設定を確認してください')
input_watch.start(on_f12, on_manual_capture, retry_stop_event)

'''+source[b:]
    source='import input_watch\n'+source
    ast.parse(source)
    return source
