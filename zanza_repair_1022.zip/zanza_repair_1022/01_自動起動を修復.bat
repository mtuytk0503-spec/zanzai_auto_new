@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>&1
if errorlevel 1 (
  python "startup_repair.py" 
) else (
  py -3 "startup_repair.py" 
)
pause
