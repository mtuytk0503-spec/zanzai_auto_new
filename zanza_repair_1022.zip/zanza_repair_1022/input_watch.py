"""Monitor only F12 / Ctrl+F8 without consuming or injecting any key events."""
import ctypes
import logging
import os
import threading
import time


class Edges:
    def __init__(self):
        self.previous = None

    def sample(self, f12, f8, ctrl, shift, alt, win):
        current = (bool(f12), bool(f8))
        if self.previous is None:
            self.previous = current
            return []
        old = self.previous
        self.previous = current
        events = []
        if f12 and not old[0] and not (ctrl or shift or alt or win):
            events.append('f12')
        if f8 and not old[1] and ctrl and not (shift or alt or win):
            events.append('manual')
        return events


def start(on_f12, on_manual, stop):
    if os.name != 'nt':
        raise RuntimeError('入力監視はWindows専用です')
    user32 = ctypes.WinDLL('user32', use_last_error=True)
    user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
    user32.GetAsyncKeyState.restype = ctypes.c_short
    def down(key):
        return bool(user32.GetAsyncKeyState(key) & 0x8000)
    def loop():
        edges = Edges()
        heartbeat = 0
        count = 0
        logging.info('[INPUT-WATCH] STARTED method=GetAsyncKeyState keys=F12,Ctrl+F8')
        try:
            while not stop.is_set():
                events = edges.sample(down(0x7B), down(0x77), down(0x11), down(0x10), down(0x12), down(0x5B) or down(0x5C))
                for event in events:
                    count += 1
                    logging.info('[INPUT-WATCH] EDGE key=%s', event)
                    callback = on_f12 if event == 'f12' else on_manual
                    threading.Thread(target=callback, name='input-dispatch', daemon=True).start()
                if time.monotonic() >= heartbeat:
                    logging.info('[INPUT-WATCH] ALIVE accepted_edges=%d', count)
                    heartbeat = time.monotonic() + 30
                stop.wait(.02)
        except Exception:
            logging.exception('[INPUT-WATCH] FAILED')
    worker = threading.Thread(target=loop, name='input-watch', daemon=True)
    worker.start()
    return worker


class PopupGate:
    def __init__(self, context, screen, stop):
        self.context = context
        self.screen = screen
        self.stop = stop
        self.approved = None
        self.lock = threading.Lock()

    def refresh(self):
        context = self.context()
        approved = None
        if context and self.screen(context['window']):
            current = self.context()
            if current and current['window']._hWnd == context['window']._hWnd:
                approved = (context['window']._hWnd, time.monotonic())
        with self.lock:
            self.approved = approved

    def allowed(self, hwnd=None):
        try:
            current = self.context()
            if not current:
                return False
            active = current['window']._hWnd
            with self.lock:
                approved = self.approved
            return bool(approved and approved[0] == active and
                        (hwnd is None or hwnd == active) and time.monotonic() - approved[1] < 2)
        except Exception:
            return False

    def start(self):
        def loop():
            while not self.stop.is_set():
                try:
                    self.refresh()
                except Exception:
                    with self.lock:
                        self.approved = None
                self.stop.wait(.5)
        thread = threading.Thread(target=loop, name='popup-gate', daemon=True)
        thread.start()
        return thread
