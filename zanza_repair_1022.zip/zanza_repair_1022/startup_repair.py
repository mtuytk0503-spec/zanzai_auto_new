"""Rebuild the user's existing startup entry with Unicode path support."""
import json
import os
from pathlib import Path
from datetime import datetime
import sys


def script_for(folder, launcher):
    def quoted(value):
        return '"' + str(value).replace('"', '""') + '"'
    return '\r\n'.join([
        'Option Explicit',
        'Dim sh, fs, baseDir, bat, cmd, logFile, code',
        'Set sh = CreateObject("WScript.Shell")',
        'Set fs = CreateObject("Scripting.FileSystemObject")',
        'baseDir = ' + quoted(folder),
        'bat = ' + quoted(Path(folder) / launcher),
        'If Not fs.FileExists(bat) Then',
        '  MsgBox "Startup file not found:" & vbCrLf & bat, 16, "Zanza"',
        '  WScript.Quit 2',
        'End If',
        'sh.CurrentDirectory = baseDir',
        'If Not fs.FolderExists(baseDir & "\\logs") Then fs.CreateFolder(baseDir & "\\logs")',
        'On Error Resume Next',
        'Set logFile = fs.OpenTextFile(baseDir & "\\logs\\autostart.log", 8, True, -1)',
        'logFile.WriteLine Now & " START " & bat',
        'logFile.Close',
        'On Error GoTo 0',
        'cmd = Chr(34) & sh.ExpandEnvironmentStrings("%ComSpec%") & Chr(34) & " /d /s /c " & Chr(34) & Chr(34) & bat & Chr(34) & Chr(34)',
        'On Error Resume Next',
        'code = sh.Run(cmd, 0, True)',
        'If Err.Number <> 0 Then',
        '  MsgBox "Startup failed: " & Err.Description & vbCrLf & bat, 16, "Zanza"',
        'End If',
        'Set logFile = fs.OpenTextFile(baseDir & "\\logs\\autostart.log", 8, True, -1)',
        'logFile.WriteLine Now & " LAUNCH_RETURN code=" & code & " error=" & Err.Number',
        'logFile.Close',
        ''
    ])


def register(folder, startup):
    folder = Path(folder).resolve()
    options = [x for x in ('02_step11_start.bat', 'start.bat') if (folder / x).is_file()]
    if len(options) != 1:
        raise ValueError('普段使う起動BATが1つある運用フォルダを指定してください')
    launcher = options[0]
    app = 'zanza.pyw' if launcher == 'start.bat' else 'zanza_system_step11_countdown_popup_manual_capture.pyw'
    if not (folder / app).is_file():
        raise ValueError('起動BATに対応する本体がありません')
    path = Path(startup) / 'ZanzaStep11_AutoStart.vbs'
    path.parent.mkdir(parents=True, exist_ok=True)
    backup = folder / 'startup_backup' / datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    backup.mkdir(parents=True)
    if path.exists():
        (backup / path.name).write_bytes(path.read_bytes())
    (backup / 'registration.json').write_text(json.dumps({'folder':str(folder), 'launcher':launcher, 'entry':str(path)}, ensure_ascii=False), encoding='utf-8')
    data = script_for(folder, launcher).encode('utf-16')
    temporary = path.with_suffix('.tmp')
    temporary.write_bytes(data)
    temporary.replace(path)
    print('自動起動を修復しました。登録先:', path)
    print('起動先:', folder / launcher)
    print('次回ログイン後、logs/autostart.logとシステムの稼働表示を確認してください。')


if __name__ == '__main__':
    try:
        if os.name != 'nt': raise ValueError('Windows端末で実行してください')
        folder = input('手動起動できる運用フォルダを指定: ').strip().strip('"')
        if not folder: raise ValueError('フォルダが未指定です')
        register(folder, Path(os.environ['APPDATA']) / 'Microsoft/Windows/Start Menu/Programs/Startup')
    except Exception as error:
        print('中止:', error)
        sys.exit(1)
