@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>&1
if errorlevel 1 (
  python "update.py" --restore
) else (
  py -3 "update.py" --restore
)
pause
