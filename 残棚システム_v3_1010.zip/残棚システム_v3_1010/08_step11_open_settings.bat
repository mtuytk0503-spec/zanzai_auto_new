@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0zanza_step11_settings.json" (
  echo [ERROR] zanza_step11_settings.json が見つかりません。
  pause
  exit /b 1
)
start "" notepad.exe "%~dp0zanza_step11_settings.json"
exit /b 0
