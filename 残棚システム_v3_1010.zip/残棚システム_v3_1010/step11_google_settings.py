from __future__ import annotations

import datetime as dt
import pathlib
import py_compile
import re
import shutil
import sys
from typing import Dict, Iterable, Tuple
from urllib.parse import urlparse

BASE_DIR = pathlib.Path(__file__).resolve().parent
TARGET_NAMES = (
    "zanza_system_step10_safe_background_OCR10_1.pyw",
    "zanza_system_step11_countdown_popup_manual_capture.pyw",
)

ASSIGNMENTS = {
    "spreadsheet": "SPREADSHEET_URL",
    "lane1": "DRIVE_FOLDER_ID_LANE1",
    "lane2": "DRIVE_FOLDER_ID_LANE2",
}

PLACEHOLDERS = {
    "your_spreadsheet_id_here",
    "your_lane1_drive_folder_id_here",
    "your_lane2_drive_folder_id_here",
}


class ConfigError(RuntimeError):
    pass


def read_text(path: pathlib.Path) -> Tuple[str, str]:
    data = path.read_bytes()
    for encoding in ("utf-8-sig", "utf-8", "cp932"):
        try:
            return data.decode(encoding).replace("\r\n", "\n").replace("\r", "\n"), encoding
        except UnicodeDecodeError:
            continue
    raise ConfigError(f"文字コードを判定できません: {path}")


def extract_assignment(text: str, name: str) -> str:
    match = re.search(
        rf'(?m)^\s*{re.escape(name)}\s*=\s*([\"\'])(.*?)\1\s*$',
        text,
    )
    return match.group(2) if match else ""


def replace_assignment(text: str, name: str, value: str) -> str:
    pattern = rf'(?m)^(\s*{re.escape(name)}\s*=\s*)([\"\'])(.*?)\2(\s*)$'
    escaped = value.replace('\\', '\\\\').replace('"', '\\"')
    replacement = rf'\1"{escaped}"\4'
    updated, count = re.subn(pattern, replacement, text, count=1)
    if count != 1:
        raise ConfigError(f"{name} の設定行を特定できませんでした。")
    return updated


def normalize_spreadsheet(value: str) -> str:
    value = value.strip()
    if not value:
        return ""
    if value.startswith("http://") or value.startswith("https://"):
        match = re.search(r"/spreadsheets/d/([A-Za-z0-9_-]+)", value)
        if not match:
            raise ConfigError("GoogleスプレッドシートURLの形式を確認してください。")
        return f"https://docs.google.com/spreadsheets/d/{match.group(1)}/edit"
    if re.fullmatch(r"[A-Za-z0-9_-]{20,}", value):
        return f"https://docs.google.com/spreadsheets/d/{value}/edit"
    raise ConfigError("スプレッドシートURLまたはIDの形式を確認してください。")


def normalize_folder_id(value: str) -> str:
    value = value.strip()
    if not value:
        return ""
    if value.startswith("http://") or value.startswith("https://"):
        match = re.search(r"/folders/([A-Za-z0-9_-]+)", value)
        if not match:
            raise ConfigError("Google DriveフォルダURLの形式を確認してください。")
        value = match.group(1)
    if not re.fullmatch(r"[A-Za-z0-9_-]{10,}", value):
        raise ConfigError("Google DriveフォルダIDの形式を確認してください。")
    return value


def masked(value: str) -> str:
    if not value:
        return "未設定"
    if any(p in value for p in PLACEHOLDERS):
        return "仮の値（未設定）"
    if len(value) <= 14:
        return value
    return value[:7] + "..." + value[-5:]


def current_values(targets: Iterable[pathlib.Path]) -> Dict[str, str]:
    result = {"spreadsheet": "", "lane1": "", "lane2": ""}
    for path in targets:
        text, _ = read_text(path)
        for key, name in ASSIGNMENTS.items():
            value = extract_assignment(text, name)
            if value and not any(p in value for p in PLACEHOLDERS):
                result[key] = value
        if all(result.values()):
            break
    return result


def prompt(label: str, current: str) -> str:
    print(f"\n{label}")
    print(f"現在値: {masked(current)}")
    value = input("新しいURL/IDを入力（変更しない場合はEnter）: ").strip()
    return value or current


def main() -> int:
    targets = [BASE_DIR / name for name in TARGET_NAMES if (BASE_DIR / name).exists()]
    if not targets:
        raise ConfigError("設定対象の.pywファイルが見つかりません。ZIPを展開し直してください。")

    print("残材管理システム Google連携設定")
    print("=" * 62)
    print("入力内容は、同梱の元ファイルと改善11ファイルの両方へ反映します。")
    print("client_secret.jsonやtoken.pickleの中身は変更しません。")

    current = current_values(reversed(targets))

    spreadsheet = normalize_spreadsheet(
        prompt("1. GoogleスプレッドシートURL、またはスプレッドシートID", current["spreadsheet"])
    )
    lane1 = normalize_folder_id(
        prompt("2. 3号残棚写真のGoogle DriveフォルダURL、またはフォルダID", current["lane1"])
    )
    lane2 = normalize_folder_id(
        prompt("3. 4号残棚写真のGoogle DriveフォルダURL、またはフォルダID", current["lane2"])
    )

    values = {"spreadsheet": spreadsheet, "lane1": lane1, "lane2": lane2}
    missing = [key for key, value in values.items() if not value or any(p in value for p in PLACEHOLDERS)]
    if missing:
        raise ConfigError("必要なGoogle設定がすべて入力されていません。")

    print("\n反映内容")
    print(f"スプレッドシート: {masked(spreadsheet)}")
    print(f"3号フォルダ      : {masked(lane1)}")
    print(f"4号フォルダ      : {masked(lane2)}")
    answer = input("\nこの内容で反映しますか？ [y/N]: ").strip().lower()
    if answer not in {"y", "yes"}:
        print("キャンセルしました。")
        return 0

    backup_dir = BASE_DIR / "backup_google_settings"
    backup_dir.mkdir(exist_ok=True)
    timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")

    written = []
    try:
        for path in targets:
            text, _ = read_text(path)
            updated = replace_assignment(text, ASSIGNMENTS["spreadsheet"], spreadsheet)
            updated = replace_assignment(updated, ASSIGNMENTS["lane1"], lane1)
            updated = replace_assignment(updated, ASSIGNMENTS["lane2"], lane2)

            backup = backup_dir / f"{path.stem}_{timestamp}{path.suffix}.bak"
            shutil.copy2(path, backup)
            path.write_text(updated, encoding="utf-8-sig", newline="\n")
            py_compile.compile(str(path), doraise=True)
            written.append((path, backup))
    except Exception:
        for path, backup in written:
            shutil.copy2(backup, path)
        raise

    report = BASE_DIR / "step11_google_settings_result.txt"
    lines = [
        "残材管理システム Google連携設定結果",
        "=" * 48,
        f"更新日時: {dt.datetime.now().isoformat(timespec='seconds')}",
        f"スプレッドシート: {spreadsheet}",
        f"3号フォルダID: {lane1}",
        f"4号フォルダID: {lane2}",
        "更新ファイル:",
    ]
    lines.extend(f"  - {path.name}" for path, _ in written)
    lines.append("構文確認: OK")
    report.write_text("\n".join(lines) + "\n", encoding="utf-8-sig")

    print("\n[OK] Google連携設定を反映しました。")
    print("次に 07_step11_environment_check.bat を実行してください。")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except ConfigError as exc:
        print(f"\n[ERROR] {exc}")
        raise SystemExit(1)
    except Exception as exc:
        print(f"\n[ERROR] 設定の反映中にエラーが発生しました: {exc}")
        raise SystemExit(2)
