@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

if not exist "%~dp0zanza_runtime_status.json" (
  echo 状態ファイルがありません。
  echo システムが未起動、または起動直後の可能性があります。
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$p='%~dp0zanza_runtime_status.json'; try {$j=Get-Content -LiteralPath $p -Raw -Encoding UTF8 | ConvertFrom-Json; Write-Host '========================================'; Write-Host ('状態              : ' + $j.status); Write-Host ('起動時刻          : ' + $j.started_at); Write-Host ('最終ハートビート  : ' + $j.heartbeat_at); Write-Host ('3号カメラ         : ' + $j.camera1_connected); Write-Host ('4号カメラ         : ' + $j.camera2_connected); Write-Host ('未送信件数        : ' + $j.pending_uploads); Write-Host ('手動撮影キー      : ' + $j.manual_capture_hotkey); Write-Host ('撮影タイマー      : ' + $j.capture_countdown_seconds + '秒'); Write-Host ('3号状態           : ' + $j.lane1_status + ' / ' + $j.lane1_shelf); Write-Host ('4号状態           : ' + $j.lane2_status + ' / ' + $j.lane2_shelf); Write-Host '========================================'} catch {Write-Host ('状態ファイル読込エラー: ' + $_.Exception.Message); exit 1}"

pause
exit /b %ERRORLEVEL%
