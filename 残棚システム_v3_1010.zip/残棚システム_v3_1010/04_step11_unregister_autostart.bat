@echo off
chcp 65001 >nul
setlocal
set "AUTOSTART=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\ZanzaStep11_AutoStart.vbs"

if exist "%AUTOSTART%" del /q "%AUTOSTART%"

if exist "%AUTOSTART%" (
  echo [ERROR] 自動起動を解除できませんでした。
  pause
  exit /b 1
)

echo [OK] 改善11の自動起動を解除しました。
pause
exit /b 0
