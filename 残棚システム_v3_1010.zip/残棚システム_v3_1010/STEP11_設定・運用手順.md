# 残材管理システム 改善11 完全セット 設定・運用手順

## 1. 同梱内容

このパッケージには、ご指定の元ファイルと、改善11を適用済みの実行本体を両方入れています。

- `zanza_system_step10_safe_background_OCR10_1.pyw`：元ファイル
- `zanza_system_step11_countdown_popup_manual_capture.pyw`：改善11適用済み本体
- `zanza_step11_settings.json`：タイマー・手動キー・通知位置
- `01_step11_install.bat`：元ファイルから改善11を再生成
- `02_step11_start_silent.vbs`：バックグラウンド起動
- `03_step11_register_autostart.bat`：Windowsログイン時の自動起動
- `04_step11_unregister_autostart.bat`：自動起動解除
- `05_step11_stop.bat`：安全終了
- `06_step11_status.bat`：稼働状態確認
- `07_step11_environment_check.bat`：環境・設定確認
- `08_step11_open_settings.bat`：設定JSONを開く
- `09_step11_set_google_settings.bat`：Google連携先を入力

`client_secret.json`と`token.pickle`は利用者固有の認証情報なので、パッケージには含めていません。

## 2. 追加した動作

### 通常撮影

1. 対象の残材画面で1回目のF12を押す
2. 棚番号をOCRして記憶
3. 入庫・出庫作業を行う
4. 既存の3分待機後、2回目のF12を押す
5. 画面右上に「撮影まで3 → 2 → 1」を表示
6. カウントダウン終了時点の最新カメラ画像を保存
7. 「✓ 写真撮影完了」を表示
8. Google登録成功なら「Google登録完了」、失敗なら「写真保存済み・送信待ち」を表示

### 手動撮影

標準キーは`Ctrl + Shift + F11`です。3号または4号の残材画面を前面にし、キーを押すと、棚番号をOCRして3秒後に撮影します。通常F12の3分待機は使いません。

### Alt+Tab

カウントダウン開始後、撮影と送信はバックグラウンドで継続します。ただし、F12または手動撮影キーを押す瞬間は、対象の3号・4号残材画面を前面にしてください。

## 3. 導入手順

### 手順1：ZIPを新しいフォルダへ展開

現在稼働中のフォルダへ直接上書き展開しないでください。同梱元ファイルと同じ名前のファイルがあるため、現行設定を上書きする可能性があります。

### 手順2：旧版を停止

既存の停止BAT、またはタスクマネージャーで旧版を停止します。改善11の`05_step11_stop.bat`も、同じフォルダで動作する版へ終了要求を送れます。

### 手順3：Google認証ファイルをコピー

旧運用フォルダから次を、新しい改善11フォルダへコピーします。

- `client_secret.json`
- `token.pickle`

未送信データが残っている場合は、旧版を停止した状態で`pending_uploads`フォルダもコピーしてください。

### 手順4：現行元ファイルを使うか決める

会社PCで現在使用中の`zanza_system_step10_safe_background_OCR10_1.pyw`に、実際のGoogle設定や会社固有の修正が入っている場合は、そのファイルを新しいフォルダの同名ファイルへ上書きしてください。

その後、`01_step11_install.bat`を実行すると、実際の設定を引き継いだ改善11本体が再生成されます。元ファイルは`backup_step11`へ自動バックアップされます。

同梱元ファイルをそのまま使用する場合も、必要に応じて`01_step11_install.bat`で再生成できます。改善11本体は最初から同梱しているため、再生成しなくても構文上は起動できます。

### 手順5：Google連携先を設定

`09_step11_set_google_settings.bat`を実行し、次を入力します。

1. GoogleスプレッドシートURLまたはID
2. 3号残棚写真のDriveフォルダURLまたはID
3. 4号残棚写真のDriveフォルダURLまたはID

入力内容は元ファイルと改善11本体の両方へ反映され、変更前ファイルは`backup_google_settings`へ保存されます。

### 手順6：環境確認

`07_step11_environment_check.bat`を実行します。次を確認します。

- Pythonと必要ライブラリ
- Tkinter
- Tesseract
- 元ファイルと改善11本体
- GoogleスプレッドシートURL
- 3号・4号DriveフォルダID
- `client_secret.json`と`token.pickle`
- カウントダウン秒数と手動撮影キー

エラー0件になってから実機テストへ進んでください。

### 手順7：バックグラウンド起動

`02_step11_start_silent.vbs`をダブルクリックします。起動直後に画面右上へ起動通知が約4秒表示されます。

### 手順8：稼働確認

`06_step11_status.bat`を実行し、次を確認します。

- 状態：`RUNNING`
- 3号カメラ：`True`
- 4号カメラ：`True`
- 手動撮影キー：`ctrl+shift+f11`
- 撮影タイマー：`3秒`

### 手順9：実機テスト

最初に手動撮影を試します。

1. 3号の残材画面を前面にする
2. `Ctrl + Shift + F11`を押す
3. 3、2、1の表示を確認
4. 「✓ 写真撮影完了」を確認
5. 「Google登録完了」を確認
6. Driveとスプレッドシートを確認

次に4号で同じ確認を行い、その後に通常F12の1回目・2回目を確認します。

### 手順10：自動起動

すべてのテストに成功してから`03_step11_register_autostart.bat`を実行します。旧版の自動起動は解除してください。旧版が先に起動すると、二重起動防止機能により改善11が起動できません。

## 4. タイマー・手動キーの変更

`08_step11_open_settings.bat`を実行します。標準設定は次のとおりです。

```json
{
  "capture_countdown_seconds": 3,
  "manual_capture_hotkey": "ctrl+shift+f11",
  "manual_capture_suppress": true,
  "manual_capture_resets_f12_cycle": true,
  "popup_enabled": true,
  "popup_position": "top_right",
  "popup_duration_seconds": 3.0,
  "capture_complete_popup_seconds": 3.5,
  "countdown_beep_enabled": true,
  "capture_busy_release_timeout_seconds": 10.0
}
```

表示位置は`top_right`、`bottom_right`、`top_left`、`bottom_left`から選べます。変更後は`05_step11_stop.bat`で停止し、`02_step11_start_silent.vbs`で再起動してください。

## 5. トラブル時

### ポップアップが出ない

`zanza_step11_settings.json`の`popup_enabled`が`true`か確認し、環境確認でTkinterがOKか確認します。

### 手動キーが動かない

3号または4号の残材画面を前面にして試します。別ソフトと競合する場合は`manual_capture_hotkey`を`ctrl+shift+f10`などへ変更します。

### Google登録に失敗する

「写真保存済み・送信待ち」と出た場合、写真は`pending_uploads`へ保全され、自動再送されます。`09_step11_set_google_settings.bat`で連携先を確認し、`logs/zanza_system.log`も確認してください。

### 旧版が起動する

旧版のスタートアップ登録を解除し、改善11の`03_step11_register_autostart.bat`を再実行します。

## 6. 検証範囲

同梱した元ファイルと改善11本体について、Python構文確認、パッチ適用、必要マーカー、ファイル整合性を確認しています。USBカメラ、AS/400画面、Googleアカウントを組み合わせた実機テストは利用者PCで必要です。
