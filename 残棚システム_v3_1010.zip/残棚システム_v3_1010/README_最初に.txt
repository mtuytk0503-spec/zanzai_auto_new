﻿残材管理システム 改善11 完全セット　最初にお読みください
================================================================

ご指定の元ファイル
  zanza_system_step10_safe_background_OCR10_1.pyw
を、このZIPへ同梱しました。

さらに、元ファイルへ改善11を適用済みの本体も同梱しています。
  zanza_system_step11_countdown_popup_manual_capture.pyw

追加機能
--------
・通常撮影：2回目のF12後に 3 → 2 → 1 のカウントダウン
・撮影完了：「✓ 写真撮影完了」を画面右上へ表示
・送信結果：「Google登録完了」または「写真保存済み・送信待ち」を表示
・手動撮影：Ctrl + Shift + F11
・二重撮影防止
・通知画面はAS/400のフォーカスを奪わない
・カメラと送信処理はバックグラウンド継続

重要
----
このZIPには、Googleの個人認証ファイルである
  client_secret.json
  token.pickle
は含めていません。
会社PCで現在使用している運用フォルダから、新しいフォルダへコピーしてください。

また、同梱の元ファイルにはGoogleスプレッドシートURLとDriveフォルダIDの
仮文字列が残っています。初回起動前に次を実行してください。
  09_step11_set_google_settings.bat

安全な導入順序
--------------
1. ZIPを「新しいフォルダ」へ展開する
   ※現在稼働中のフォルダへ直接上書き展開しないでください。
2. 旧版を停止する
3. 旧運用フォルダから client_secret.json と token.pickle をコピーする
4. 現在使用中の元.pywに実際の設定や独自修正がある場合は、
   そのファイルをこのフォルダの同名ファイルへ上書きし、
   01_step11_install.bat を実行する
5. 09_step11_set_google_settings.bat でGoogle設定を確認・入力する
6. 07_step11_environment_check.bat を実行する
7. 02_step11_start_silent.vbs を実行する
8. 3号・4号で手動撮影と通常F12を各1回テストする
9. 問題なければ 03_step11_register_autostart.bat を実行する

主なファイル
------------
zanza_system_step10_safe_background_OCR10_1.pyw
  ご指定の元ファイル

zanza_system_step11_countdown_popup_manual_capture.pyw
  改善11適用済みの実行本体

01_step11_install.bat
  元ファイルから改善11本体を再生成する

02_step11_start_silent.vbs
  改善11を画面非表示で起動する

05_step11_stop.bat
  改善11を安全終了する

06_step11_status.bat
  稼働状態、カメラ状態、手動キーを確認する

07_step11_environment_check.bat
  Pythonライブラリ、Google設定、認証ファイルを確認する

08_step11_open_settings.bat
  タイマー、手動撮影キー、通知位置の設定を開く

09_step11_set_google_settings.bat
  スプレッドシートURLと3号・4号DriveフォルダIDを対話入力する

詳しい説明は STEP11_設定・運用手順.txt を確認してください。
