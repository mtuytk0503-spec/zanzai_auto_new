@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
set "AUTOSTART=%STARTUP%\ZanzaStep11_AutoStart.vbs"
set "TARGET=%~dp002_step11_start_silent.vbs"

if not exist "%TARGET%" (
  echo [ERROR] 起動用VBSが見つかりません: %TARGET%
  pause
  exit /b 1
)

> "%AUTOSTART%" echo Option Explicit
>> "%AUTOSTART%" echo Dim shell
>> "%AUTOSTART%" echo Set shell = CreateObject^("WScript.Shell"^)
>> "%AUTOSTART%" echo shell.Run Chr^(34^) ^& "%TARGET%" ^& Chr^(34^), 0, False

if not exist "%AUTOSTART%" (
  echo [ERROR] 自動起動ファイルを作成できませんでした。
  pause
  exit /b 1
)

echo [OK] Windowsログイン時の自動起動を登録しました。
echo 登録先: %AUTOSTART%
echo.
echo 次回ログインからバックグラウンドで起動します。
pause
exit /b 0
