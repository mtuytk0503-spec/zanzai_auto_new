from __future__ import annotations

import argparse
import datetime as dt
import json
import pathlib
import py_compile
import re
import shutil
import sys
import traceback
from typing import List, Optional, Tuple

PATCH_VERSION = "11.0"
DEFAULT_SOURCE_NAMES = (
    "zanza_system_step10_safe_background_OCR10_1.pyw",
    "zanza_system_step10_safe_background_OCR10_1(1).pyw",
)
OUTPUT_NAME = "zanza_system_step11_countdown_popup_manual_capture.pyw"
SETTINGS_NAME = "zanza_step11_settings.json"


class PatchError(RuntimeError):
    pass


def read_source(path: pathlib.Path) -> Tuple[str, str]:
    data = path.read_bytes()
    for encoding in ("utf-8-sig", "utf-8", "cp932"):
        try:
            decoded = data.decode(encoding)
            decoded = decoded.replace("\r\n", "\n").replace("\r", "\n")
            return decoded, encoding
        except UnicodeDecodeError:
            continue
    raise PatchError(f"文字コードを判定できませんでした: {path}")


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise PatchError(
            f"{label} の変更位置を特定できませんでした。想定1件、実際{count}件です。"
        )
    return text.replace(old, new, 1)





def regex_replace_once(text: str, pattern: str, replacement: str, label: str) -> str:
    updated, count = re.subn(
        pattern, lambda _match: replacement, text, count=1, flags=re.DOTALL
    )
    if count != 1:
        raise PatchError(
            f"{label} の変更位置を特定できませんでした。想定1件、実際{count}件です。"
        )
    return updated


def find_source(base_dir: pathlib.Path, explicit: Optional[str]) -> pathlib.Path:
    if explicit:
        candidate = pathlib.Path(explicit)
        if not candidate.is_absolute():
            candidate = base_dir / candidate
        if not candidate.exists():
            raise PatchError(f"指定された元ファイルが見つかりません: {candidate}")
        return candidate.resolve()

    for name in DEFAULT_SOURCE_NAMES:
        candidate = base_dir / name
        if candidate.exists():
            return candidate.resolve()

    candidates: List[pathlib.Path] = []
    for candidate in sorted(base_dir.glob("*.pyw")):
        if candidate.name == OUTPUT_NAME:
            continue
        try:
            text, _ = read_source(candidate)
        except Exception:
            continue
        required = (
            "def handle_f12_async():",
            "keyboard.add_hotkey('f12', on_f12)",
            "SHOW_CAMERA_WINDOWS = False",
            "def capture_process(",
        )
        if all(marker in text for marker in required):
            candidates.append(candidate)

    if len(candidates) == 1:
        return candidates[0].resolve()
    if not candidates:
        raise PatchError(
            "元の.pywファイルを見つけられませんでした。"
            "このファイル一式を現在運用中の.pywと同じフォルダへ置いてください。"
        )
    names = "\n  - ".join(path.name for path in candidates)
    raise PatchError(
        "候補が複数あります。01_step11_install.bat内で元ファイル名を指定してください。\n"
        f"  - {names}"
    )


def apply_patch(source: str) -> str:
    if "STEP11_PATCH_MARKER = 'ZANZA_STEP11_COUNTDOWN_POPUP_MANUAL'" in source:
        raise PatchError("このファイルにはすでに改善11が適用されています。")

    text = source

    # 1. 標準ライブラリの追加
    if "import queue\n" not in text:
        text = replace_once(
            text,
            "import threading\n",
            "import threading\nimport queue\n",
            "queueインポート",
        )

    # 2. 設定ブロック
    config_block = r'''

# ==========================================
# 改善11：撮影カウントダウン・目視通知・手動撮影
# ==========================================
STEP11_PATCH_MARKER = 'ZANZA_STEP11_COUNTDOWN_POPUP_MANUAL'
STEP11_SETTINGS_FILE = os.path.join(SCRIPT_DIR, 'zanza_step11_settings.json')

_STEP11_DEFAULTS = {
    "capture_countdown_seconds": 3,
    "manual_capture_hotkey": "ctrl+shift+f11",
    "manual_capture_suppress": True,
    "manual_capture_resets_f12_cycle": True,
    "popup_enabled": True,
    "popup_position": "top_right",
    "popup_duration_seconds": 3.0,
    "capture_complete_popup_seconds": 3.5,
    "countdown_beep_enabled": True,
    "capture_busy_release_timeout_seconds": 10.0,
}


def _load_step11_settings():
    settings = dict(_STEP11_DEFAULTS)
    try:
        if os.path.exists(STEP11_SETTINGS_FILE):
            with open(STEP11_SETTINGS_FILE, 'r', encoding='utf-8-sig') as settings_file:
                loaded = json.load(settings_file)
            if isinstance(loaded, dict):
                settings.update(loaded)
            else:
                logging.warning('⚠️ 改善11設定ファイルが辞書形式ではないため既定値を使用します。')
    except Exception as e:
        logging.warning(f'⚠️ 改善11設定ファイルを読み込めませんでした。既定値を使用します: {e}')
    return settings


_STEP11_SETTINGS = _load_step11_settings()
CAPTURE_COUNTDOWN_SECONDS = max(0, int(_STEP11_SETTINGS.get("capture_countdown_seconds", 3)))
MANUAL_CAPTURE_HOTKEY = str(
    _STEP11_SETTINGS.get("manual_capture_hotkey", "ctrl+shift+f11")
).strip()
MANUAL_CAPTURE_SUPPRESS = bool(
    _STEP11_SETTINGS.get("manual_capture_suppress", True)
)
MANUAL_CAPTURE_RESETS_F12_CYCLE = bool(
    _STEP11_SETTINGS.get("manual_capture_resets_f12_cycle", True)
)
OPERATOR_POPUP_ENABLED = bool(_STEP11_SETTINGS.get("popup_enabled", True))
OPERATOR_POPUP_POSITION = str(
    _STEP11_SETTINGS.get("popup_position", "top_right")
).strip().lower()
OPERATOR_POPUP_DURATION_SECONDS = max(
    0.5, float(_STEP11_SETTINGS.get("popup_duration_seconds", 3.0))
)
CAPTURE_COMPLETE_POPUP_SECONDS = max(
    1.0, float(_STEP11_SETTINGS.get("capture_complete_popup_seconds", 3.5))
)
COUNTDOWN_BEEP_ENABLED = bool(
    _STEP11_SETTINGS.get("countdown_beep_enabled", True)
)
CAPTURE_BUSY_RELEASE_TIMEOUT_SECONDS = max(
    2.0,
    float(_STEP11_SETTINGS.get("capture_busy_release_timeout_seconds", 10.0)),
)
'''
    text = replace_once(
        text,
        "AUTO_RETRY_SUCCESS_SOUND_ENABLED = True\n",
        "AUTO_RETRY_SUCCESS_SOUND_ENABLED = True\n" + config_block,
        "改善11設定ブロック",
    )

    # 3. 状態管理とロック
    old_state = '''state = {
    "lane1_f12_count": 0, "lane1_shelf": "未取得", "lane1_last_time": 0.0,
    "lane1_status": "READY", "lane1_status_message": "Press F12", "lane1_status_until": 0.0,
    "lane2_f12_count": 0, "lane2_shelf": "未取得", "lane2_last_time": 0.0,
    "lane2_status": "READY", "lane2_status_message": "Press F12", "lane2_status_until": 0.0,
    "last_key_press": 0.0 # 連打防止用の最終キー入力時刻
}
'''
    new_state = '''state = {
    "lane1_f12_count": 0, "lane1_shelf": "未取得", "lane1_last_time": 0.0,
    "lane1_status": "READY", "lane1_status_message": "Press F12", "lane1_status_until": 0.0,
    "lane1_capture_busy": False,
    "lane2_f12_count": 0, "lane2_shelf": "未取得", "lane2_last_time": 0.0,
    "lane2_status": "READY", "lane2_status_message": "Press F12", "lane2_status_until": 0.0,
    "lane2_capture_busy": False,
    "last_key_press": 0.0,  # F12連打防止用の最終キー入力時刻
    "last_manual_key_press": 0.0,  # 手動撮影キーの連打防止
}

# OCR・F12・手動撮影が同じレーンで重ならないようにします。
lane_input_locks = {
    "lane1": threading.Lock(),
    "lane2": threading.Lock(),
}

# カメラ取得中のフレーム参照を短時間だけ保護します。
frame_lock = threading.Lock()

# 作業者向けポップアップは専用スレッドへキューで渡し、AS/400操作を止めません。
operator_popup_queue = queue.Queue(maxsize=50)
'''
    text = replace_once(text, old_state, new_state, "状態管理")

    # 4. COUNTDOWN状態色
    text = replace_once(
        text,
        '    "WAIT": (0, 140, 255),\n',
        '    "WAIT": (0, 140, 255),\n    "COUNTDOWN": (0, 165, 255),\n',
        "COUNTDOWN状態色",
    )

    # 5. 通知音を拡張
    old_sound = '''                if sound_kind == "success":
                    winsound.Beep(1200, 150)
                    time.sleep(0.05)
                    winsound.Beep(1700, 220)
                elif sound_kind == "pending":
                    winsound.Beep(900, 180)
                    time.sleep(0.05)
                    winsound.Beep(650, 260)
                else:
                    winsound.MessageBeep(winsound.MB_ICONHAND)
'''
    new_sound = '''                if sound_kind == "countdown":
                    winsound.Beep(1050, 90)
                elif sound_kind == "capture":
                    winsound.Beep(1500, 120)
                    time.sleep(0.04)
                    winsound.Beep(1900, 180)
                elif sound_kind == "success":
                    winsound.Beep(1200, 150)
                    time.sleep(0.05)
                    winsound.Beep(1700, 220)
                elif sound_kind == "pending":
                    winsound.Beep(900, 180)
                    time.sleep(0.05)
                    winsound.Beep(650, 260)
                else:
                    winsound.MessageBeep(winsound.MB_ICONHAND)
'''
    text = replace_once(text, old_sound, new_sound, "通知音")

    # 6. フォーカスを奪わない作業者向けポップアップ
    popup_block = r'''

def show_operator_popup(title, message="", level="info", duration=None):
    """AS/400のフォーカスを奪わない小型通知を専用スレッドへ依頼する。"""
    if not OPERATOR_POPUP_ENABLED:
        return

    if duration is None:
        duration = OPERATOR_POPUP_DURATION_SECONDS

    item = {
        "title": str(title or ""),
        "message": str(message or ""),
        "level": str(level or "info").lower(),
        "duration": max(0.5, float(duration)),
    }

    try:
        operator_popup_queue.put_nowait(item)
    except queue.Full:
        # 表示側が停止してもメモリを増やし続けないよう、最古の通知を1件捨てます。
        try:
            operator_popup_queue.get_nowait()
            operator_popup_queue.put_nowait(item)
        except Exception:
            pass
    except Exception:
        # 表示失敗で撮影本体を止めないことを優先します。
        pass


def _operator_popup_worker():
    """Tkinterをこの専用スレッド内だけで操作し、通知を順次表示する。"""
    try:
        import tkinter as tk
    except Exception as e:
        logging.warning(f"⚠️ 作業者向けポップアップを開始できませんでした: {e}")
        return

    try:
        root = tk.Tk()
        root.withdraw()
        root.overrideredirect(True)
        root.attributes("-topmost", True)

        panel = tk.Frame(root, bd=0, highlightthickness=0)
        panel.pack(fill="both", expand=True)

        title_var = tk.StringVar(value="")
        message_var = tk.StringVar(value="")

        title_label = tk.Label(
            panel,
            textvariable=title_var,
            anchor="w",
            justify="left",
            padx=18,
            pady=10,
            font=("Yu Gothic UI", 18, "bold"),
            fg="white",
        )
        title_label.pack(fill="x")

        message_label = tk.Label(
            panel,
            textvariable=message_var,
            anchor="w",
            justify="left",
            padx=18,
            pady=10,
            wraplength=440,
            font=("Yu Gothic UI", 11),
            fg="white",
        )
        message_label.pack(fill="x")

        level_colors = {
            "info": "#1565C0",
            "countdown": "#9A6700",
            "capture": "#6A1B9A",
            "success": "#1B5E20",
            "warning": "#A15C00",
            "error": "#B71C1C",
        }

        hide_at = 0.0

        def apply_no_activate_style():
            if os.name != "nt":
                return
            try:
                hwnd = root.winfo_id()
                user32 = ctypes.windll.user32
                gwl_exstyle = -20
                ws_ex_toolwindow = 0x00000080
                ws_ex_transparent = 0x00000020
                ws_ex_noactivate = 0x08000000
                swp_nosize = 0x0001
                swp_nomove = 0x0002
                swp_noactivate = 0x0010
                swp_showwindow = 0x0040
                hwnd_topmost = -1

                style = user32.GetWindowLongW(hwnd, gwl_exstyle)
                style |= ws_ex_toolwindow | ws_ex_transparent | ws_ex_noactivate
                user32.SetWindowLongW(hwnd, gwl_exstyle, style)
                user32.SetWindowPos(
                    hwnd,
                    hwnd_topmost,
                    0,
                    0,
                    0,
                    0,
                    swp_nosize | swp_nomove | swp_noactivate | swp_showwindow,
                )
            except Exception as e:
                logging.debug(f"ポップアップの非アクティブ化設定を適用できませんでした: {e}")

        def show_item(item):
            nonlocal hide_at

            color = level_colors.get(item.get("level"), level_colors["info"])
            title_var.set(item.get("title", ""))
            message_var.set(item.get("message", ""))

            root.configure(bg=color)
            panel.configure(bg=color)
            title_label.configure(bg=color)
            message_label.configure(bg=color)

            root.update_idletasks()
            width = max(390, min(500, root.winfo_reqwidth()))
            height = max(110, root.winfo_reqheight())
            screen_width = root.winfo_screenwidth()
            screen_height = root.winfo_screenheight()
            margin = 22

            if OPERATOR_POPUP_POSITION == "bottom_right":
                x = max(0, screen_width - width - margin)
                y = max(0, screen_height - height - 70)
            elif OPERATOR_POPUP_POSITION == "top_left":
                x = margin
                y = margin
            elif OPERATOR_POPUP_POSITION == "bottom_left":
                x = margin
                y = max(0, screen_height - height - 70)
            else:
                x = max(0, screen_width - width - margin)
                y = margin

            root.geometry(f"{width}x{height}+{x}+{y}")
            # 表示前と表示直後の両方でNOACTIVATEを設定し、
            # AS/400からキーボードフォーカスを奪う瞬間を作らないようにします。
            apply_no_activate_style()
            try:
                root.attributes("-alpha", 0.0)
            except Exception:
                pass
            root.deiconify()
            root.update_idletasks()
            apply_no_activate_style()
            try:
                root.attributes("-alpha", 0.96)
            except Exception:
                pass

            hide_at = time.time() + float(item.get("duration", 3.0))

        def poll_queue():
            nonlocal hide_at

            if retry_stop_event.is_set():
                try:
                    root.destroy()
                except Exception:
                    pass
                return

            latest_item = None
            while True:
                try:
                    latest_item = operator_popup_queue.get_nowait()
                except queue.Empty:
                    break
                except Exception:
                    break

            if latest_item is not None:
                show_item(latest_item)
            elif hide_at and time.time() >= hide_at:
                root.withdraw()
                hide_at = 0.0

            root.after(80, poll_queue)

        root.after(0, poll_queue)
        root.mainloop()

    except Exception as e:
        logging.exception(f"❌ 作業者向けポップアップでエラーが発生しました: {e}")


def start_operator_popup_worker():
    if not OPERATOR_POPUP_ENABLED:
        return None

    popup_thread = threading.Thread(
        target=_operator_popup_worker,
        name="operator-popup",
        daemon=True,
    )
    popup_thread.start()
    return popup_thread

'''
    text = replace_once(
        text,
        "def draw_lane_status(frame, lane_key, lane_title):\n",
        popup_block + "def draw_lane_status(frame, lane_key, lane_title):\n",
        "作業者向けポップアップ",
    )


    # 6-2. 稼働確認JSONへ改善11の設定を追加
    text = replace_once(
        text,
        '        "pending_uploads": _count_pending_uploads(),\n',
        '        "pending_uploads": _count_pending_uploads(),\n'
        '        "manual_capture_hotkey": MANUAL_CAPTURE_HOTKEY,\n'
        '        "capture_countdown_seconds": CAPTURE_COUNTDOWN_SECONDS,\n',
        "稼働確認JSONの改善11情報",
    )

    # 7. フレーム取得、カウントダウン、撮影開始の共通処理
    countdown_block = r'''

def _get_latest_frame_copy(lane_key):
    """指定レーンの最新フレームを安全にコピーして返す。"""
    with frame_lock:
        if lane_key == "lane1":
            frame = latest_frame1
        elif lane_key == "lane2":
            frame = latest_frame2
        else:
            frame = None

        return frame.copy() if frame is not None else None


def _capture_countdown_worker(context, shelf_number, source_label):
    lane_key = context["lane_key"]
    lane_id = context["lane_id"]
    lane_name = context["lane_name"]

    try:
        for remaining in range(CAPTURE_COUNTDOWN_SECONDS, 0, -1):
            if retry_stop_event.is_set():
                return

            set_lane_status(
                lane_id,
                "COUNTDOWN",
                f"Capture in {remaining}s | Shelf {shelf_number}",
                duration=0,
            )
            show_operator_popup(
                f"撮影まで {remaining}",
                f"{lane_id} / 棚番号 {shelf_number}\nカメラの範囲を確認してください",
                level="countdown",
                duration=1.1,
            )
            if COUNTDOWN_BEEP_ENABLED:
                _play_notification_sound("countdown")

            if retry_stop_event.wait(1.0):
                return

        frame_copy = _get_latest_frame_copy(lane_key)
        if frame_copy is None:
            logging.error(f"❌ [{lane_name}] 最新のカメラ画像を取得できませんでした。")
            notify_lane_status(
                lane_id,
                "ERROR",
                f"Camera frame missing: {shelf_number}",
                sound_kind="error",
                duration=OPERATION_ERROR_DISPLAY_SECONDS,
            )
            show_operator_popup(
                "撮影できませんでした",
                f"{lane_id} / カメラ画像を取得できません\n棚番号 {shelf_number}",
                level="error",
                duration=OPERATION_ERROR_DISPLAY_SECONDS,
            )
            return

        set_lane_status(lane_id, "CAPTURE", f"Shelf {shelf_number}", duration=0)
        show_operator_popup(
            "撮影しています",
            f"{lane_id} / 棚番号 {shelf_number}",
            level="capture",
            duration=1.5,
        )

        local_capture_event = threading.Event()
        capture_thread = threading.Thread(
            target=capture_process,
            args=(
                context["capture_label"],
                lane_id,
                frame_copy,
                shelf_number,
                context["folder_id"],
                context["sheet_name"],
            ),
            kwargs={"local_capture_event": local_capture_event},
            name=f"capture-{lane_key}",
            daemon=True,
        )
        capture_thread.start()

        # 画像がPC内へ保存された時点、または安全タイムアウト後に次の撮影を許可します。
        local_capture_event.wait(CAPTURE_BUSY_RELEASE_TIMEOUT_SECONDS)

    except Exception as e:
        logging.exception(f"❌ [{lane_name}] カウントダウン撮影処理でエラーが発生しました: {e}")
        show_operator_popup(
            "撮影処理エラー",
            f"{lane_id} / {e}",
            level="error",
            duration=OPERATION_ERROR_DISPLAY_SECONDS,
        )
    finally:
        with state_lock:
            state[f"{lane_key}_capture_busy"] = False


def _start_countdown_capture(context, shelf_number, source_label):
    lane_key = context["lane_key"]
    lane_id = context["lane_id"]

    with state_lock:
        if state.get(f"{lane_key}_capture_busy", False):
            show_operator_popup(
                "撮影処理中です",
                f"{lane_id}の撮影完了をお待ちください",
                level="warning",
                duration=2.5,
            )
            return False
        state[f"{lane_key}_capture_busy"] = True

    logging.info(
        f"📷 [{context['lane_name']}] {source_label}による撮影予約: "
        f"棚番号 {shelf_number} / {CAPTURE_COUNTDOWN_SECONDS}秒後"
    )

    threading.Thread(
        target=_capture_countdown_worker,
        args=(context, shelf_number, source_label),
        name=f"countdown-{lane_key}",
        daemon=True,
    ).start()
    return True

'''
    text = replace_once(
        text,
        "def capture_process(lane_label, lane_id, frame, shelf_number, folder_id, sheet_name):\n",
        countdown_block
        + "def capture_process(lane_label, lane_id, frame, shelf_number, folder_id, sheet_name, local_capture_event=None):\n",
        "カウントダウン共通処理",
    )

    # 8. PC内への画像保存完了を目視表示し、busy解除用イベントを通知
    old_local_save = '''        with open(file_path, "wb") as image_file:
            image_file.write(buffer)

        notify_lane_status(lane_id, "SENDING", f"Shelf {shelf_number}", duration=0)
'''
    new_local_save = '''        with open(file_path, "wb") as image_file:
            image_file.write(buffer)

        if local_capture_event is not None:
            local_capture_event.set()

        show_operator_popup(
            "✓ 写真撮影完了",
            f"{lane_id} / 棚番号 {shelf_number}\\n保存時刻 {datetime.now().strftime('%H:%M:%S')}",
            level="success",
            duration=CAPTURE_COMPLETE_POPUP_SECONDS,
        )
        _play_notification_sound("capture")

        notify_lane_status(lane_id, "SENDING", f"Shelf {shelf_number}", duration=0)
'''
    text = replace_once(text, old_local_save, new_local_save, "撮影完了表示")


    # 8-2. Google登録結果も作業者へ表示
    old_sync_success = '''                notify_lane_status(
                    lane_id,
                    "SUCCESS",
                    f"Uploaded: {shelf_number}",
                    sound_kind="success",
                )
'''
    new_sync_success = '''                notify_lane_status(
                    lane_id,
                    "SUCCESS",
                    f"Uploaded: {shelf_number}",
                    sound_kind="success",
                )
                show_operator_popup(
                    "Google登録完了",
                    f"{lane_id} / 棚番号 {shelf_number}",
                    level="success",
                    duration=OPERATOR_POPUP_DURATION_SECONDS,
                )
'''
    text = replace_once(text, old_sync_success, new_sync_success, "Google登録完了表示")

    old_pending_notice = '''                    notify_lane_status(
                        lane_id,
                        "PENDING",
                        f"Saved locally: {shelf_number}",
                        sound_kind="pending",
                        duration=OPERATION_ERROR_DISPLAY_SECONDS,
                    )
'''
    new_pending_notice = '''                    notify_lane_status(
                        lane_id,
                        "PENDING",
                        f"Saved locally: {shelf_number}",
                        sound_kind="pending",
                        duration=OPERATION_ERROR_DISPLAY_SECONDS,
                    )
                    show_operator_popup(
                        "写真保存済み・送信待ち",
                        f"{lane_id} / 棚番号 {shelf_number}\\n通信復旧後に自動送信します",
                        level="warning",
                        duration=OPERATION_ERROR_DISPLAY_SECONDS,
                    )
'''
    text = replace_once(
        text,
        old_pending_notice,
        new_pending_notice,
        "通常送信失敗時の未送信保全表示",
    )

    old_exception_pending_notice = '''            notify_lane_status(
                lane_id,
                "PENDING",
                f"Saved locally: {shelf_number}",
                sound_kind="pending",
                duration=OPERATION_ERROR_DISPLAY_SECONDS,
            )
'''
    new_exception_pending_notice = '''            notify_lane_status(
                lane_id,
                "PENDING",
                f"Saved locally: {shelf_number}",
                sound_kind="pending",
                duration=OPERATION_ERROR_DISPLAY_SECONDS,
            )
            show_operator_popup(
                "写真保存済み・送信待ち",
                f"{lane_id} / 棚番号 {shelf_number}\\n通信復旧後に自動送信します",
                level="warning",
                duration=OPERATION_ERROR_DISPLAY_SECONDS,
            )
'''
    text = replace_once(
        text,
        old_exception_pending_notice,
        new_exception_pending_notice,
        "例外時の未送信保全表示",
    )

    old_manual_recovery = '''                    notify_lane_status(
                        lane_id,
                        "ERROR",
                        f"Manual recovery: {shelf_number}",
                        sound_kind="error",
                        duration=OPERATION_ERROR_DISPLAY_SECONDS,
                    )
'''
    new_manual_recovery = '''                    notify_lane_status(
                        lane_id,
                        "ERROR",
                        f"Manual recovery: {shelf_number}",
                        sound_kind="error",
                        duration=OPERATION_ERROR_DISPLAY_SECONDS,
                    )
                    show_operator_popup(
                        "送信保全エラー",
                        f"{lane_id} / 棚番号 {shelf_number}\\n写真ファイルを手動で確認してください",
                        level="error",
                        duration=OPERATION_ERROR_DISPLAY_SECONDS,
                    )
'''
    text = replace_once(
        text,
        old_manual_recovery,
        new_manual_recovery,
        "手動保全エラー表示",
    )

    old_capture_failed = '''            notify_lane_status(
                lane_id,
                "ERROR",
                f"Capture failed: {shelf_number}",
                sound_kind="error",
                duration=OPERATION_ERROR_DISPLAY_SECONDS,
            )
'''
    new_capture_failed = '''            notify_lane_status(
                lane_id,
                "ERROR",
                f"Capture failed: {shelf_number}",
                sound_kind="error",
                duration=OPERATION_ERROR_DISPLAY_SECONDS,
            )
            show_operator_popup(
                "撮影処理エラー",
                f"{lane_id} / 棚番号 {shelf_number}\\nログを確認してください",
                level="error",
                duration=OPERATION_ERROR_DISPLAY_SECONDS,
            )
'''
    text = replace_once(
        text,
        old_capture_failed,
        new_capture_failed,
        "撮影処理エラー表示",
    )

    # 9. F12処理・手動撮影処理・ホットキー登録を置換
    hotkey_block = r'''def _get_active_lane_context():
    active_window = gw.getActiveWindow()
    if not active_window:
        return None

    title = str(active_window.title or "")
    if LANE1_WINDOW_TITLE in title:
        return {
            "lane_key": "lane1",
            "lane_name": "3号レーン",
            "capture_label": "Lane1",
            "lane_id": "3号",
            "window": active_window,
            "folder_id": DRIVE_FOLDER_ID_LANE1,
            "sheet_name": SHEET_NAME_LANE1,
        }
    if LANE2_WINDOW_TITLE in title:
        return {
            "lane_key": "lane2",
            "lane_name": "4号レーン",
            "capture_label": "Lane2",
            "lane_id": "4号",
            "window": active_window,
            "folder_id": DRIVE_FOLDER_ID_LANE2,
            "sheet_name": SHEET_NAME_LANE2,
        }
    return None


def handle_f12_async():
    context = _get_active_lane_context()
    if context is None:
        # F12は他ソフトでも使うため、対象画面以外では何も表示せず通過させます。
        return

    lane_key = context["lane_key"]
    lane_id = context["lane_id"]
    lane_name = context["lane_name"]
    input_lock = lane_input_locks[lane_key]

    if not input_lock.acquire(blocking=False):
        return

    try:
        if not is_target_screen(context["window"]):
            return

        current_time = time.time()
        with state_lock:
            if state.get(f"{lane_key}_capture_busy", False):
                show_operator_popup(
                    "撮影処理中です",
                    f"{lane_id}の撮影完了をお待ちください",
                    level="warning",
                    duration=2.5,
                )
                return
            f12_count = int(state.get(f"{lane_key}_f12_count", 0))
            last_time = float(state.get(f"{lane_key}_last_time", 0.0))

        if f12_count == 0:
            if (current_time - last_time) < COOLDOWN_SECONDS:
                return

            logging.info(f"[{lane_name}] 🟢 1回目F12を検知。棚番号を読み取ります。")
            ocr_shelf = extract_shelf_number(context["window"])
            is_valid, normalized_shelf, validation_error = validate_shelf_number(ocr_shelf)

            if not is_valid:
                with state_lock:
                    state[f"{lane_key}_f12_count"] = 0
                    state[f"{lane_key}_shelf"] = "未取得"
                    state[f"{lane_key}_last_time"] = current_time
                notify_shelf_validation_error(lane_name, ocr_shelf, validation_error)
                show_operator_popup(
                    "棚番号を読み取れませんでした",
                    f"{lane_id} / {validation_error}\n画面を確認してF12を押し直してください",
                    level="error",
                    duration=OPERATION_ERROR_DISPLAY_SECONDS,
                )
                return

            with state_lock:
                state[f"{lane_key}_shelf"] = normalized_shelf
                state[f"{lane_key}_f12_count"] = 1
                state[f"{lane_key}_last_time"] = current_time

            set_lane_status(lane_id, "WAIT", f"Shelf {normalized_shelf}", duration=0)
            show_operator_popup(
                "棚番号を記憶しました",
                f"{lane_id} / 棚番号 {normalized_shelf}\n入出庫後、F12をもう一度押してください",
                level="info",
                duration=4.0,
            )
            return

        elapsed = current_time - last_time
        if elapsed < LOCKOUT_SECONDS:
            remaining = max(1, int(LOCKOUT_SECONDS - elapsed + 0.999))
            logging.warning(
                f"[{lane_name}] ⏳ 作業中ロック: 撮影可能まで残り約{remaining}秒。"
            )
            show_operator_popup(
                "まだ撮影できません",
                f"{lane_id} / 撮影可能まで残り約 {remaining} 秒",
                level="warning",
                duration=3.0,
            )
            return

        with state_lock:
            saved_shelf = state.get(f"{lane_key}_shelf", "未取得")

        is_valid, normalized_shelf, validation_error = validate_shelf_number(saved_shelf)
        with state_lock:
            state[f"{lane_key}_f12_count"] = 0
            state[f"{lane_key}_shelf"] = "未取得"
            state[f"{lane_key}_last_time"] = current_time

        if not is_valid:
            notify_shelf_validation_error(lane_name, saved_shelf, validation_error)
            show_operator_popup(
                "撮影を開始できません",
                f"{lane_id} / {validation_error}",
                level="error",
                duration=OPERATION_ERROR_DISPLAY_SECONDS,
            )
            return

        _start_countdown_capture(context, normalized_shelf, "2回目F12")

    except Exception as e:
        logging.exception(f"❌ F12処理エラー: {e}")
    finally:
        input_lock.release()


def handle_manual_capture_async():
    context = _get_active_lane_context()
    if context is None:
        show_operator_popup(
            "手動撮影できません",
            "3号または4号の残材画面を前面に表示してください",
            level="warning",
            duration=3.5,
        )
        return

    lane_key = context["lane_key"]
    lane_id = context["lane_id"]
    lane_name = context["lane_name"]
    input_lock = lane_input_locks[lane_key]

    if not input_lock.acquire(blocking=False):
        show_operator_popup(
            "処理中です",
            f"{lane_id}の画面読取完了をお待ちください",
            level="warning",
            duration=2.5,
        )
        return

    try:
        if not is_target_screen(context["window"]):
            show_operator_popup(
                "手動撮影できません",
                f"{lane_id}の残材画面を表示してください",
                level="warning",
                duration=3.5,
            )
            return

        with state_lock:
            if state.get(f"{lane_key}_capture_busy", False):
                show_operator_popup(
                    "撮影処理中です",
                    f"{lane_id}の撮影完了をお待ちください",
                    level="warning",
                    duration=2.5,
                )
                return

        logging.info(f"[{lane_name}] ⌨️ 手動撮影キーを検知。棚番号を読み取ります。")
        ocr_shelf = extract_shelf_number(context["window"])
        is_valid, normalized_shelf, validation_error = validate_shelf_number(ocr_shelf)
        if not is_valid:
            notify_shelf_validation_error(lane_name, ocr_shelf, validation_error)
            show_operator_popup(
                "手動撮影できません",
                f"{lane_id} / {validation_error}",
                level="error",
                duration=OPERATION_ERROR_DISPLAY_SECONDS,
            )
            return

        if MANUAL_CAPTURE_RESETS_F12_CYCLE:
            with state_lock:
                state[f"{lane_key}_f12_count"] = 0
                state[f"{lane_key}_shelf"] = "未取得"
                state[f"{lane_key}_last_time"] = time.time()

        _start_countdown_capture(context, normalized_shelf, "手動撮影キー")

    except Exception as e:
        logging.exception(f"❌ 手動撮影処理エラー: {e}")
        show_operator_popup(
            "手動撮影エラー",
            str(e),
            level="error",
            duration=OPERATION_ERROR_DISPLAY_SECONDS,
        )
    finally:
        input_lock.release()


def on_f12():
    current_time = time.time()
    with state_lock:
        if current_time - state.get("last_key_press", 0) < DEBOUNCE_SECONDS:
            return
        state["last_key_press"] = current_time

    threading.Thread(
        target=handle_f12_async,
        name="f12-handler",
        daemon=True,
    ).start()


def on_manual_capture():
    current_time = time.time()
    with state_lock:
        if current_time - state.get("last_manual_key_press", 0) < 1.0:
            return
        state["last_manual_key_press"] = current_time

    threading.Thread(
        target=handle_manual_capture_async,
        name="manual-capture-handler",
        daemon=True,
    ).start()


popup_thread = start_operator_popup_worker()
keyboard.add_hotkey('f12', on_f12)

if MANUAL_CAPTURE_HOTKEY.replace(" ", "").lower() == "f12":
    logging.error("❌ 手動撮影キーにF12は指定できません。通常操作と競合するため無効化します。")
    show_operator_popup(
        "手動撮影キー設定エラー",
        "F12以外のキー組み合わせを設定してください",
        level="error",
        duration=OPERATION_ERROR_DISPLAY_SECONDS,
    )
elif MANUAL_CAPTURE_HOTKEY:
    try:
        keyboard.add_hotkey(
            MANUAL_CAPTURE_HOTKEY,
            on_manual_capture,
            suppress=MANUAL_CAPTURE_SUPPRESS,
        )
    except Exception as e:
        logging.exception(
            f"❌ 手動撮影キーを登録できませんでした: {MANUAL_CAPTURE_HOTKEY} / {e}"
        )
        show_operator_popup(
            "手動撮影キーの登録失敗",
            f"設定キー: {MANUAL_CAPTURE_HOTKEY}",
            level="error",
            duration=OPERATION_ERROR_DISPLAY_SECONDS,
        )
'''

    text = regex_replace_once(
        text,
        r"def handle_f12_async\(\):.*?keyboard\.add_hotkey\('f12', on_f12\)\n",
        hotkey_block + "\n",
        "F12・手動撮影処理",
    )

    # 10. カメラフレーム更新をロック保護
    text = replace_once(
        text,
        "                latest_frame1 = frame1\n",
        "                with frame_lock:\n                    latest_frame1 = frame1\n",
        "3号カメラフレーム更新",
    )
    text = replace_once(
        text,
        "                latest_frame2 = frame2\n",
        "                with frame_lock:\n                    latest_frame2 = frame2\n",
        "4号カメラフレーム更新",
    )

    # 11. 起動ログと初回表示
    text = replace_once(
        text,
        'logging.info(" 🚀 残材管理システム（改善10.1・緑文字OCR強化版）起動完了")\n',
        'logging.info(" 🚀 残材管理システム（改善11・カウントダウン／手動撮影版）起動完了")\n',
        "起動ログ見出し",
    )
    text = replace_once(
        text,
        "logging.info(f\"🕶️ カメラ画面表示: {'ON' if SHOW_CAMERA_WINDOWS else 'OFF（バックグラウンド）'}\")\n",
        "logging.info(f\"🕶️ カメラ画面表示: {'ON' if SHOW_CAMERA_WINDOWS else 'OFF（バックグラウンド）'}\")\n"
        "logging.info(f\"⏱️ 撮影カウントダウン: {CAPTURE_COUNTDOWN_SECONDS}秒\")\n"
        "logging.info(f\"⌨️ 手動撮影キー: {MANUAL_CAPTURE_HOTKEY or '無効'}\")\n"
        "logging.info(f\"🪟 作業者向け目視通知: {'ON' if OPERATOR_POPUP_ENABLED else 'OFF'}\")\n"
        "show_operator_popup(\n"
        "    \"残材管理システム起動\",\n"
        "    f\"通常撮影: F12を2回 / 手動撮影: {MANUAL_CAPTURE_HOTKEY}\",\n"
        "    level=\"info\",\n"
        "    duration=4.0,\n"
        ")\n",
        "改善11起動情報",
    )

    # 12. 終了時にホットキーを解除
    text = replace_once(
        text,
        "    _release_single_instance_mutex()\n",
        "    try:\n"
        "        keyboard.unhook_all_hotkeys()\n"
        "    except Exception:\n"
        "        pass\n\n"
        "    _release_single_instance_mutex()\n",
        "ホットキー解除",
    )

    return text


def write_default_settings(path: pathlib.Path) -> None:
    if path.exists():
        return
    settings = {
        "capture_countdown_seconds": 3,
        "manual_capture_hotkey": "ctrl+shift+f11",
        "manual_capture_suppress": True,
        "manual_capture_resets_f12_cycle": True,
        "popup_enabled": True,
        "popup_position": "top_right",
        "popup_duration_seconds": 3.0,
        "capture_complete_popup_seconds": 3.5,
        "countdown_beep_enabled": True,
        "capture_busy_release_timeout_seconds": 10.0,
    }
    path.write_text(
        json.dumps(settings, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8-sig",
    )


def main() -> int:
    parser = argparse.ArgumentParser(
        description="残材管理システム改善11パッチを適用します。"
    )
    parser.add_argument(
        "--source",
        help="元の.pywファイル名またはフルパス。省略時は同じフォルダから自動検出。",
    )
    parser.add_argument(
        "--output",
        default=OUTPUT_NAME,
        help=f"出力ファイル名（既定: {OUTPUT_NAME}）",
    )
    args = parser.parse_args()

    base_dir = pathlib.Path(__file__).resolve().parent
    source_path = find_source(base_dir, args.source)
    output_path = pathlib.Path(args.output)
    if not output_path.is_absolute():
        output_path = base_dir / output_path
    output_path = output_path.resolve()

    if source_path == output_path:
        raise PatchError("元ファイルと出力ファイルが同じです。別名を指定してください。")

    source_text, source_encoding = read_source(source_path)
    patched_text = apply_patch(source_text)

    backup_dir = base_dir / "backup_step11"
    backup_dir.mkdir(exist_ok=True)
    timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = backup_dir / f"{source_path.stem}_{timestamp}{source_path.suffix}"
    shutil.copy2(source_path, backup_path)

    with output_path.open("w", encoding="utf-8-sig", newline="\n") as output_file:
        output_file.write(patched_text)
    settings_path = base_dir / SETTINGS_NAME
    write_default_settings(settings_path)

    try:
        py_compile.compile(str(output_path), doraise=True)
    except Exception:
        try:
            output_path.unlink(missing_ok=True)
        except Exception:
            pass
        raise PatchError(
            "生成ファイルの構文確認に失敗しました。出力ファイルは削除しました。\n"
            + traceback.format_exc()
        )

    report_path = base_dir / "step11_install_result.txt"
    report = (
        "残材管理システム 改善11 インストール結果\n"
        "========================================\n"
        f"パッチ版: {PATCH_VERSION}\n"
        f"元ファイル: {source_path}\n"
        f"元文字コード: {source_encoding}\n"
        f"生成ファイル: {output_path}\n"
        f"設定ファイル: {settings_path}\n"
        f"バックアップ: {backup_path}\n"
        "構文確認: OK\n"
    )
    report_path.write_text(report, encoding="utf-8-sig")

    print(report)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except PatchError as e:
        print("\n[ERROR] 改善11の適用に失敗しました。")
        print(str(e))
        raise SystemExit(1)
    except Exception:
        print("\n[ERROR] 想定外のエラーが発生しました。")
        traceback.print_exc()
        raise SystemExit(2)
