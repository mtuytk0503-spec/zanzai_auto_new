from __future__ import annotations

import importlib
import json
import os
import pathlib
import platform
import re
import sys

BASE_DIR = pathlib.Path(__file__).resolve().parent
APP_NAME = "zanza_system_step11_countdown_popup_manual_capture.pyw"
SOURCE_NAME = "zanza_system_step10_safe_background_OCR10_1.pyw"
SETTINGS_NAME = "zanza_step11_settings.json"
TESSERACT_PATH = pathlib.Path(r"C:\Program Files\Tesseract-OCR\tesseract.exe")

MODULES = {
    "keyboard": "グローバルホットキー",
    "cv2": "USBカメラ・画像処理",
    "pygetwindow": "対象ウィンドウ判定",
    "pyautogui": "AS/400画面キャプチャ",
    "pytesseract": "棚番号OCR",
    "numpy": "画像前処理",
    "gspread": "Googleスプレッドシート連携",
    "google.auth.transport.requests": "Google認証更新",
    "google_auth_oauthlib.flow": "Google OAuth認証",
    "googleapiclient.discovery": "Google Drive API",
}

PLACEHOLDERS = (
    "your_spreadsheet_id_here",
    "your_lane1_drive_folder_id_here",
    "your_lane2_drive_folder_id_here",
)


def ok(message: str) -> None:
    print(f"[OK]   {message}")


def warn(message: str) -> None:
    print(f"[WARN] {message}")


def error(message: str) -> None:
    print(f"[ERROR] {message}")


def read_code(path: pathlib.Path) -> str:
    return path.read_text(encoding="utf-8-sig")


def assignment_value(source: str, name: str) -> str:
    match = re.search(rf'(?m)^\s*{re.escape(name)}\s*=\s*([\"\'])(.*?)\1\s*$', source)
    return match.group(2) if match else ""


def main() -> int:
    errors = 0
    warnings = 0

    print("残材管理システム 改善11 環境確認")
    print("=" * 62)
    print(f"Python: {sys.version.split()[0]} / {sys.executable}")
    print(f"OS: {platform.platform()}")
    print(f"フォルダ: {BASE_DIR}")
    print("=" * 62)

    if os.name == "nt":
        ok("Windows環境です")
    else:
        warn("実運用対象はWindowsです。現在は構文・ファイル確認のみ可能です")
        warnings += 1

    try:
        import tkinter  # noqa: F401
        ok("Tkinter: 撮影カウントダウン・完了表示に使用できます")
    except Exception as exc:
        error(f"Tkinterを読み込めません: {exc}")
        errors += 1

    for module_name, purpose in MODULES.items():
        try:
            importlib.import_module(module_name)
            ok(f"{module_name}: {purpose}")
        except Exception as exc:
            error(f"{module_name}: 未導入または読込失敗 ({purpose}) / {exc}")
            errors += 1

    if TESSERACT_PATH.exists():
        ok(f"Tesseract: {TESSERACT_PATH}")
    else:
        error(f"Tesseractが見つかりません: {TESSERACT_PATH}")
        errors += 1

    source_path = BASE_DIR / SOURCE_NAME
    if source_path.exists():
        ok(f"同梱元ファイル: {source_path.name}")
    else:
        error(f"同梱元ファイルがありません: {SOURCE_NAME}")
        errors += 1

    app_path = BASE_DIR / APP_NAME
    app_source = ""
    if app_path.exists():
        ok(f"改善11本体: {app_path.name}")
        try:
            app_source = read_code(app_path)
            if "STEP11_PATCH_MARKER = 'ZANZA_STEP11_COUNTDOWN_POPUP_MANUAL'" in app_source:
                ok("改善11パッチマーカーを確認しました")
            else:
                error("改善11パッチマーカーがありません。01_step11_install.batを実行してください")
                errors += 1
        except Exception as exc:
            error(f"改善11本体を確認できません: {exc}")
            errors += 1
    else:
        error("改善11本体がありません。01_step11_install.batを実行してください")
        errors += 1

    if app_source:
        google_values = {
            "スプレッドシート": assignment_value(app_source, "SPREADSHEET_URL"),
            "3号Driveフォルダ": assignment_value(app_source, "DRIVE_FOLDER_ID_LANE1"),
            "4号Driveフォルダ": assignment_value(app_source, "DRIVE_FOLDER_ID_LANE2"),
        }
        for label, value in google_values.items():
            if not value or any(p in value for p in PLACEHOLDERS):
                error(f"{label}が未設定です。09_step11_set_google_settings.batを実行してください")
                errors += 1
            else:
                ok(f"{label}が設定されています")

    settings_path = BASE_DIR / SETTINGS_NAME
    if settings_path.exists():
        try:
            settings = json.loads(settings_path.read_text(encoding="utf-8-sig"))
            countdown = int(settings.get("capture_countdown_seconds", 3))
            hotkey = str(settings.get("manual_capture_hotkey", ""))
            position = str(settings.get("popup_position", "top_right"))
            ok(f"設定: カウントダウン={countdown}秒 / 手動キー={hotkey or '無効'} / 表示位置={position}")
            if countdown < 0 or countdown > 10:
                warn("カウントダウンは0～10秒程度を推奨します")
                warnings += 1
            if hotkey.replace(" ", "").lower() == "f12":
                error("手動撮影キーにF12は指定できません")
                errors += 1
            elif hotkey and not re.fullmatch(r"[a-z0-9+_ -]+", hotkey.lower()):
                warn("手動撮影キーの表記を確認してください")
                warnings += 1
        except Exception as exc:
            error(f"設定ファイルを読み込めません: {exc}")
            errors += 1
    else:
        error(f"設定ファイルがありません: {SETTINGS_NAME}")
        errors += 1

    has_secret = (BASE_DIR / "client_secret.json").exists()
    has_token = (BASE_DIR / "token.pickle").exists()
    if has_secret:
        ok("client_secret.jsonがあります")
    else:
        warn("client_secret.jsonがありません。旧運用フォルダからコピーしてください")
        warnings += 1
    if has_token:
        ok("token.pickleがあります")
    else:
        warn("token.pickleがありません。旧運用フォルダからコピーするか、初回認証してください")
        warnings += 1
    if not has_secret and not has_token:
        error("Google認証ファイルがありません。client_secret.jsonまたはtoken.pickleが必要です")
        errors += 1

    print("=" * 62)
    print(f"結果: エラー {errors}件 / 警告 {warnings}件")
    if errors:
        print("エラーを解消してから本運用してください。")
        return 1
    print("主要な起動条件を確認できました。3号・4号を各1回テストしてください。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
