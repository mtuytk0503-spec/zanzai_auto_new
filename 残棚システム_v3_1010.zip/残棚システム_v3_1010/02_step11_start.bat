@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set "APP=%~dp0zanza_system_step11_countdown_popup_manual_capture.pyw"

rem 現在の運用で特定のpythonw.exeを使っている場合だけ、次の行へフルパスを設定します。
rem 例: set "PYTHONW_EXE=C:\Users\user\AppData\Local\Programs\Python\Python311\pythonw.exe"
set "PYTHONW_EXE="

if not exist "%APP%" (
  echo [ERROR] 改善11の本体が見つかりません。
  echo 先に 01_step11_install.bat を実行してください。
  exit /b 1
)

if defined PYTHONW_EXE (
  if exist "%PYTHONW_EXE%" (
    start "" /b "%PYTHONW_EXE%" "%APP%"
    exit /b 0
  )
)

rem 元の.pywをダブルクリックして起動できるPCでは、同じ関連付けを最優先します。
assoc .pyw >nul 2>&1
if not errorlevel 1 (
  start "" "%APP%"
  exit /b 0
)

where pyw.exe >nul 2>&1
if not errorlevel 1 (
  start "" /b pyw.exe -3 "%APP%"
  exit /b 0
)

where pythonw.exe >nul 2>&1
if not errorlevel 1 (
  start "" /b pythonw.exe "%APP%"
  exit /b 0
)

echo [ERROR] .pywを起動できるPythonを見つけられませんでした。
echo 現在の旧版で使っているpythonw.exeのパスを、このBATのPYTHONW_EXEへ設定してください。
exit /b 1
