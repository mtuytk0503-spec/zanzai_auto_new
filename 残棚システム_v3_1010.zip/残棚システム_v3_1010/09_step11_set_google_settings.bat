@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo GoogleスプレッドシートURLと、3号・4号のDriveフォルダIDを設定します。
echo 入力前に、現在運用中のシステムで使っている値を確認してください。
echo.

where py.exe >nul 2>&1
if not errorlevel 1 (
  py -3 "%~dp0step11_google_settings.py"
  set "RESULT=%ERRORLEVEL%"
  goto DONE
)

where python.exe >nul 2>&1
if not errorlevel 1 (
  python "%~dp0step11_google_settings.py"
  set "RESULT=%ERRORLEVEL%"
  goto DONE
)

echo [ERROR] Pythonを見つけられませんでした。
set "RESULT=1"

:DONE
echo.
pause
exit /b %RESULT%
