@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

> "%~dp0zanza_stop_request.flag" echo STOP

echo 終了要求を送信しました。
echo 通常は数秒以内に安全終了します。
timeout /t 3 /nobreak >nul

if exist "%~dp0zanza_runtime_status.json" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$p='%~dp0zanza_runtime_status.json'; try {$j=Get-Content -LiteralPath $p -Raw -Encoding UTF8 | ConvertFrom-Json; Write-Host ('現在状態: ' + $j.status + ' / 最終更新: ' + $j.heartbeat_at)} catch {Write-Host '状態ファイルを確認できませんでした。'}"
)

pause
exit /b 0
