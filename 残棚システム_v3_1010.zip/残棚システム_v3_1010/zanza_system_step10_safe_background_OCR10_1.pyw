﻿import keyboard
import cv2
import time
import pygetwindow as gw
import pyautogui
import pytesseract
import re
import threading
import uuid
import os
import json
import shutil
import logging
from logging.handlers import TimedRotatingFileHandler
import pickle
import unicodedata
import sys
import ctypes
import numpy as np # 画像前処理用
from datetime import datetime, timedelta

# 💡 Google公式ライブラリ
import gspread
from google.auth.transport.requests import Request
from google_auth_oauthlib.flow import InstalledAppFlow 
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

# ==========================================
# ⚙️ 0. ログ出力の設定（改善9：完全バックグラウンド動作）
# ==========================================
# .pyw / pythonw.exe でコンソールを出さずに常駐するため、ログはファイルへ保存します。
# Pythonファイルと同じ場所の logs フォルダへ保存し、過去30日分を保持します。
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_DIR = os.path.join(SCRIPT_DIR, 'logs')
LOG_FILE = os.path.join(LOG_DIR, 'zanza_system.log')
LOG_RETENTION_DAYS = 30

log_formatter = logging.Formatter(
    "%(asctime)s [%(levelname)s] [%(threadName)s] %(message)s"
)

log_handlers = []
try:
    os.makedirs(LOG_DIR, exist_ok=True)
    file_handler = TimedRotatingFileHandler(
        LOG_FILE,
        when='midnight',
        interval=1,
        backupCount=LOG_RETENTION_DAYS,
        encoding='utf-8',
        delay=True,
    )
    file_handler.setFormatter(log_formatter)
    log_handlers.append(file_handler)
except OSError:
    # .pywでは画面出力先がないため、ログ準備に失敗しても本体を止めないNullHandlerへ退避します。
    log_handlers.append(logging.NullHandler())

logging.basicConfig(
    level=logging.INFO,
    handlers=log_handlers,
    force=True,
)

# ==========================================
# 改善9：バックグラウンド表示・稼働確認設定
# ==========================================
# False の場合、2台のカメラ映像ウィンドウを一切表示しません。
SHOW_CAMERA_WINDOWS = False

# 稼働確認用JSONを5秒ごとに更新します。
RUNTIME_STATUS_FILE = os.path.join(SCRIPT_DIR, 'zanza_runtime_status.json')
RUNTIME_STATUS_INTERVAL_SECONDS = 5
RUNTIME_STATUS_STALE_SECONDS = 20
SYSTEM_STARTED_AT = datetime.now().isoformat(timespec='seconds')

# ==========================================
# 改善10：安全終了・二重起動防止
# ==========================================
# Windowsの名前付きMutexで、手動ダブルクリックを含む二重起動を防止します。
SINGLE_INSTANCE_MUTEX_NAME = r"Local\ZanzaRemainingMaterialSystem"
ERROR_ALREADY_EXISTS = 183
_single_instance_mutex = None

# zanza_stop.bat がこのファイルを作成すると、メインループが検知して正常終了します。
STOP_REQUEST_FILE = os.path.join(SCRIPT_DIR, 'zanza_stop_request.flag')


def _acquire_single_instance_mutex():
    """Windows上で同一システムがすでに起動中ならFalseを返す。"""
    global _single_instance_mutex

    if os.name != 'nt':
        # 実運用はWindows。Windows以外では開発・構文確認を妨げないため通過します。
        return True

    try:
        kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel32.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_bool, ctypes.c_wchar_p]
        kernel32.CreateMutexW.restype = ctypes.c_void_p
        kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
        kernel32.CloseHandle.restype = ctypes.c_bool

        handle = kernel32.CreateMutexW(None, False, SINGLE_INSTANCE_MUTEX_NAME)
        if not handle:
            logging.error('❌ 二重起動防止Mutexを作成できませんでした。安全のため起動を中止します。')
            return False

        if ctypes.get_last_error() == ERROR_ALREADY_EXISTS:
            kernel32.CloseHandle(handle)
            logging.warning('⚠️ 残材管理システムはすでに起動中です。二重起動を防止したため、この起動は終了します。')
            return False

        _single_instance_mutex = handle
        return True
    except Exception as e:
        logging.exception(f'❌ 二重起動防止の初期化に失敗しました。安全のため起動を中止します: {e}')
        return False


def _release_single_instance_mutex():
    """正常終了時にMutexハンドルを解放する。"""
    global _single_instance_mutex
    if os.name == 'nt' and _single_instance_mutex:
        try:
            ctypes.WinDLL('kernel32', use_last_error=True).CloseHandle(_single_instance_mutex)
        except Exception:
            pass
        _single_instance_mutex = None


def _clear_stale_stop_request():
    """前回の強制終了などで残った終了要求ファイルを起動時に除去する。"""
    try:
        if os.path.exists(STOP_REQUEST_FILE):
            os.remove(STOP_REQUEST_FILE)
            logging.info('🧹 前回残った終了要求ファイルを削除しました。')
    except OSError as e:
        logging.warning(f'⚠️ 古い終了要求ファイルを削除できませんでした: {e}')


def _stop_requested():
    return os.path.exists(STOP_REQUEST_FILE)


# Google認証やUSBカメラを開く前に二重起動を判定します。
if not _acquire_single_instance_mutex():
    raise SystemExit(0)
_clear_stale_stop_request()

# ==========================================
# ⚙️ 1. OCRとAS400画面の設定
# ==========================================
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

LANE1_WINDOW_TITLE = "3号台車"
LANE2_WINDOW_TITLE = "4号台車"
TARGET_SCREEN_KEYWORD = "残材" 
EXCLUDE_KEYWORD = "管理"       

BBOX_TITLE_RELATIVE = (770, 0, 320, 50)
BBOX_SHELF_RELATIVE = (410, 290, 315, 60)

COOLDOWN_SECONDS = 2.0   
LOCKOUT_SECONDS = 180.0  # 1回目の呼出から2回目の撮影を許可するまでの待機秒数（3分）
DEBOUNCE_SECONDS = 0.5   # キーボード連打防止（チャタリング対策）用の待機秒数

# ==========================================
# 棚番号の形式チェック設定
# ==========================================
# 現在の運用に合わせ、「数字-数字-数字」の3区分を正常な棚番号とします。
# 各数字の桁数や範囲は制限していないため、既存の棚番号を不必要に拒否しません。
SHELF_NUMBER_PATTERN = re.compile(r'^[0-9]+-[0-9]+-[0-9]+$')
SHELF_NUMBER_MAX_LENGTH = 32
SHELF_NUMBER_ERROR_VALUES = {"", "未取得", "読取エラー", "システムエラー"}

# OCR失敗時にWindowsの警告音を1回鳴らします。不要な場合はFalseへ変更してください。
OCR_ERROR_BEEP_ENABLED = True

# ==========================================
# 撮影・送信結果の画面／音通知設定
# ==========================================
# カメラ映像の上部へ、READY / WAIT / SENDING / SUCCESS / PENDING / ERRORを表示します。
OPERATION_STATUS_DISPLAY_SECONDS = 8.0
OPERATION_ERROR_DISPLAY_SECONDS = 12.0

# 撮影結果の音を不要にする場合はFalseへ変更してください。
OPERATION_SOUND_ENABLED = True

# 未送信写真の自動再送が成功した際にも成功音を鳴らします。
AUTO_RETRY_SUCCESS_SOUND_ENABLED = True

# ==========================================
# ⚙️ 2. Google連携の設定
# ==========================================
# 🚨 取得した人間用の鍵の名前に変更してください
GOOGLE_JSON_FILE = "client_secret.json" 
SPREADSHEET_URL = "https://docs.google.com/spreadsheets/d/19LUhzMZYMY_YhpYgwDff1JmPq44zEZhrzStP5BbCFAg/edit"

SHEET_NAME_LANE1 = "3号"
# 🚨 新しく作った「3号残棚写真」フォルダのIDを入れてください
DRIVE_FOLDER_ID_LANE1 = "1x9uf47FyYg-KzjhVjyokgsZxn_iCqBbh"

SHEET_NAME_LANE2 = "4号"
# 🚨 新しく作った「4号残棚写真」フォルダのIDを入れてください
DRIVE_FOLDER_ID_LANE2 = "1hcbuJaoi8ZLC2NbetB0AE53--64z1zOr"

# ==========================================
# ⚙️ 3. Google APIクライアントの初期化 (人間用OAuth2.0方式)
# ==========================================
BASE_DIR = SCRIPT_DIR
json_path = os.path.join(BASE_DIR, GOOGLE_JSON_FILE)
token_path = os.path.join(BASE_DIR, 'token.pickle')
SCOPES = ['https://www.googleapis.com/auth/spreadsheets', 'https://www.googleapis.com/auth/drive']

# ==========================================
# 未送信データの一時保管先
# ==========================================
# Google Driveやスプレッドシートへの送信に失敗した写真を、
# 次回の再送機能で利用できる形で残しておくフォルダです。
PENDING_DIR = os.path.join(BASE_DIR, 'pending_uploads')
try:
    os.makedirs(PENDING_DIR, exist_ok=True)
except OSError as e:
    logging.error(f"❌ 未送信フォルダを作成できませんでした: {e}")

# ==========================================
# 未送信データの自動再送設定
# ==========================================
# 15秒ごとに未送信フォルダを確認します。実際の再送間隔は、
# 失敗回数に応じて30秒 → 1分 → 5分 → 15分 → 30分と延ばします。
PENDING_RETRY_SCAN_SECONDS = 15
PENDING_RETRY_INITIAL_DELAY_SECONDS = 5
PENDING_RETRY_BACKOFF_SECONDS = (30, 60, 300, 900, 1800)
PENDING_RETRY_MAX_PER_CYCLE = 5

drive_service = None
gc = None
creds = None

try:
    if os.path.exists(token_path):
        with open(token_path, 'rb') as token:
            creds = pickle.load(token)

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        elif os.path.exists(json_path):
            flow = InstalledAppFlow.from_client_secrets_file(json_path, SCOPES)
            creds = flow.run_local_server(port=0)
            with open(token_path, 'wb') as token:
                pickle.dump(creds, token)
        else:
            logging.warning("⚠️ Google OAuthキー(client_secret.json)が見つかりません。")

    if creds:
        drive_service = build('drive', 'v3', credentials=creds)
        gc = gspread.authorize(creds)
        logging.info("☁️ Google APIの初期認証に成功しました。")

except Exception as e:
    logging.error(f"❌ Google APIの初期化エラー: {e}")

# ==========================================
# 状態管理・カメラ初期設定
# ==========================================
# 通知関数をF12処理中から呼び出すため、同じスレッドが再取得できるRLockを使います。
state_lock = threading.RLock()

# Google Drive・スプレッドシートへの書き込みと未送信キューの整理を
# 1件ずつ順番に行い、通常撮影と自動再送の競合を防ぎます。
sync_operation_lock = threading.Lock()
notification_sound_lock = threading.Lock()
retry_stop_event = threading.Event()
state = {
    "lane1_f12_count": 0, "lane1_shelf": "未取得", "lane1_last_time": 0.0,
    "lane1_status": "READY", "lane1_status_message": "Press F12", "lane1_status_until": 0.0,
    "lane2_f12_count": 0, "lane2_shelf": "未取得", "lane2_last_time": 0.0,
    "lane2_status": "READY", "lane2_status_message": "Press F12", "lane2_status_until": 0.0,
    "last_key_press": 0.0 # 連打防止用の最終キー入力時刻
}

# 稼働確認ファイルへ出すためのカメラ状態。
runtime_lock = threading.Lock()
runtime_camera_state = {
    "lane1_connected": False,
    "lane2_connected": False,
    "lane1_last_frame_at": None,
    "lane2_last_frame_at": None,
}

cap1 = cv2.VideoCapture(0)
cap2 = cv2.VideoCapture(1)

latest_frame1 = None
latest_frame2 = None

# OpenCVは日本語文字を標準では描画できないため、カメラ画面の通知は
# 英数字で表示します。ログには従来どおり日本語を残します。
LANE_STATUS_COLORS = {
    "READY": (80, 80, 80),
    "WAIT": (0, 140, 255),
    "CAPTURE": (180, 110, 0),
    "SENDING": (180, 110, 0),
    "RETRY": (180, 110, 0),
    "SUCCESS": (0, 150, 0),
    "PENDING": (0, 140, 255),
    "ERROR": (0, 0, 190),
}


def _lane_key(lane_identifier):
    """3号・4号、Lane1・Lane2の表記を内部キーへ変換する。"""
    value = str(lane_identifier or "").lower()
    if "lane1" in value or "3号" in value or value in {"3", "lane1"}:
        return "lane1"
    if "lane2" in value or "4号" in value or value in {"4", "lane2"}:
        return "lane2"
    return None


def set_lane_status(lane_identifier, status, message="", duration=None):
    """カメラ画面へ表示するレーン別状態を更新する。"""
    lane_key = _lane_key(lane_identifier)
    if lane_key is None:
        return

    status = str(status or "READY").upper()
    if status not in LANE_STATUS_COLORS:
        status = "READY"

    if duration is None:
        duration = OPERATION_STATUS_DISPLAY_SECONDS

    # durationが0以下の場合は、次の状態更新まで表示を継続します。
    status_until = 0.0 if duration <= 0 else time.time() + float(duration)

    with state_lock:
        state[f"{lane_key}_status"] = status
        state[f"{lane_key}_status_message"] = str(message or "")
        state[f"{lane_key}_status_until"] = status_until


def _play_notification_sound(sound_kind):
    """Windowsの標準機能で、結果別の短い通知音を非同期再生する。"""
    if not OPERATION_SOUND_ENABLED or not sound_kind:
        return

    def sound_worker():
        try:
            import winsound

            with notification_sound_lock:
                if sound_kind == "success":
                    winsound.Beep(1200, 150)
                    time.sleep(0.05)
                    winsound.Beep(1700, 220)
                elif sound_kind == "pending":
                    winsound.Beep(900, 180)
                    time.sleep(0.05)
                    winsound.Beep(650, 260)
                else:
                    winsound.MessageBeep(winsound.MB_ICONHAND)
        except Exception:
            # 音声機能が使えない環境でも、画面表示と本処理は継続します。
            pass

    threading.Thread(
        target=sound_worker,
        name=f"notification-{sound_kind}",
        daemon=True,
    ).start()


def notify_lane_status(lane_identifier, status, message="", sound_kind=None, duration=None):
    """レーン別の画面表示と通知音をまとめて実行する。"""
    set_lane_status(lane_identifier, status, message, duration)
    _play_notification_sound(sound_kind)


def draw_lane_status(frame, lane_key, lane_title):
    """従来のカメラ映像へ状態バーを重ね、表示用フレームを返す。"""
    width = 480
    display_frame = cv2.resize(
        frame,
        (width, int((width / frame.shape[1]) * frame.shape[0])),
    )

    now = time.time()
    with state_lock:
        f12_count = int(state.get(f"{lane_key}_f12_count", 0))
        shelf_number = str(state.get(f"{lane_key}_shelf", "未取得"))
        last_time = float(state.get(f"{lane_key}_last_time", 0.0))
        status = str(state.get(f"{lane_key}_status", "READY"))
        message = str(state.get(f"{lane_key}_status_message", ""))
        status_until = float(state.get(f"{lane_key}_status_until", 0.0))

    # 結果表示の時間が終わったら、現在のF12待機状態を自動表示します。
    if status_until > 0 and now >= status_until:
        if f12_count == 1:
            remaining = max(0, int(LOCKOUT_SECONDS - (now - last_time)))
            status = "WAIT"
            message = f"Shelf {shelf_number} | Ready in {remaining}s"
        else:
            status = "READY"
            message = "Press F12 on target screen"
    elif status == "WAIT" and f12_count == 1:
        remaining = max(0, int(LOCKOUT_SECONDS - (now - last_time)))
        message = f"Shelf {shelf_number} | Ready in {remaining}s"

    color = LANE_STATUS_COLORS.get(status, LANE_STATUS_COLORS["READY"])
    frame_height, frame_width = display_frame.shape[:2]
    bar_height = min(64, frame_height)

    overlay = display_frame.copy()
    cv2.rectangle(overlay, (0, 0), (frame_width, bar_height), color, -1)
    cv2.addWeighted(overlay, 0.86, display_frame, 0.14, 0, display_frame)

    cv2.putText(
        display_frame,
        f"{lane_title}  |  {status}",
        (12, 25),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.62,
        (255, 255, 255),
        2,
        cv2.LINE_AA,
    )
    cv2.putText(
        display_frame,
        message[:56],
        (12, 51),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.48,
        (255, 255, 255),
        1,
        cv2.LINE_AA,
    )
    return display_frame


def _count_pending_uploads():
    """未送信JSONの件数を返す。確認失敗時は-1。"""
    try:
        return sum(
            1 for name in os.listdir(PENDING_DIR)
            if name.lower().endswith('.json')
        )
    except OSError:
        return -1


def _write_runtime_status():
    """別プロセスから稼働確認できるよう、現在状態をJSONへ原子的に保存する。"""
    now = datetime.now()
    with runtime_lock:
        camera_snapshot = dict(runtime_camera_state)

    with state_lock:
        status_snapshot = {
            "lane1_status": str(state.get("lane1_status", "READY")),
            "lane1_shelf": str(state.get("lane1_shelf", "未取得")),
            "lane2_status": str(state.get("lane2_status", "READY")),
            "lane2_shelf": str(state.get("lane2_shelf", "未取得")),
        }

    payload = {
        "status": "RUNNING",
        "pid": os.getpid(),
        "started_at": SYSTEM_STARTED_AT,
        "heartbeat_at": now.isoformat(timespec='seconds'),
        "heartbeat_unix": time.time(),
        "camera1_connected": bool(camera_snapshot.get("lane1_connected")),
        "camera2_connected": bool(camera_snapshot.get("lane2_connected")),
        "camera1_last_frame_at": camera_snapshot.get("lane1_last_frame_at"),
        "camera2_last_frame_at": camera_snapshot.get("lane2_last_frame_at"),
        "pending_uploads": _count_pending_uploads(),
        **status_snapshot,
        "log_file": LOG_FILE,
    }

    temp_path = f"{RUNTIME_STATUS_FILE}.tmp"
    try:
        with open(temp_path, 'w', encoding='utf-8') as status_file:
            json.dump(payload, status_file, ensure_ascii=False, indent=2)
        os.replace(temp_path, RUNTIME_STATUS_FILE)
        return True
    except OSError as e:
        logging.warning(f"⚠️ 稼働確認ファイルを更新できませんでした: {e}")
        try:
            if os.path.exists(temp_path):
                os.remove(temp_path)
        except OSError:
            pass
        return False


def runtime_status_worker():
    """5秒ごとにハートビートを書き込み、バックグラウンド稼働を外部確認可能にする。"""
    logging.info(
        f"💓 稼働確認ハートビートを開始しました: {RUNTIME_STATUS_FILE} "
        f"（{RUNTIME_STATUS_INTERVAL_SECONDS}秒間隔）"
    )
    while not retry_stop_event.is_set():
        _write_runtime_status()
        retry_stop_event.wait(RUNTIME_STATUS_INTERVAL_SECONDS)

    # 正常終了時はRUNNINGのまま残さず、STOPPEDへ書き換える。
    try:
        payload = {
            "status": "STOPPED",
            "pid": os.getpid(),
            "started_at": SYSTEM_STARTED_AT,
            "heartbeat_at": datetime.now().isoformat(timespec='seconds'),
            "heartbeat_unix": time.time(),
            "log_file": LOG_FILE,
        }
        temp_path = f"{RUNTIME_STATUS_FILE}.tmp"
        with open(temp_path, 'w', encoding='utf-8') as status_file:
            json.dump(payload, status_file, ensure_ascii=False, indent=2)
        os.replace(temp_path, RUNTIME_STATUS_FILE)
    except OSError:
        pass


def get_absolute_bbox(window, relative_bbox, padding_x=10, padding_y=5):
    win_left = window.left
    win_top = window.top
    rel_x, rel_y, width, height = relative_bbox
    return (win_left + rel_x - padding_x, win_top + rel_y - padding_y, width + (padding_x * 2), height + (padding_y * 2))


def normalize_shelf_number(value):
    """OCR結果や旧データの表記揺れを、棚番号の標準表記へ整える。"""
    if value is None:
        return ""

    text = unicodedata.normalize("NFKC", str(value)).strip()

    # スプレッドシートで文字列化するために付けた先頭のアポストロフィは除去します。
    text = text.lstrip("'").strip()

    # OCRやコピー元によって混ざる可能性があるハイフン類を半角ハイフンへ統一します。
    for dash in ("‐", "‑", "‒", "–", "—", "―", "−"):
        text = text.replace(dash, "-")

    # OCRが数字の間へ空白や改行を入れた場合に備えて除去します。
    return re.sub(r"\s+", "", text)


def validate_shelf_number(value):
    """棚番号を検証し、(正常か, 正規化済み棚番号, 理由)を返す。"""
    normalized = normalize_shelf_number(value)

    if normalized in SHELF_NUMBER_ERROR_VALUES:
        return False, normalized, "OCRで棚番号を取得できませんでした"

    if len(normalized) > SHELF_NUMBER_MAX_LENGTH:
        return False, normalized, f"棚番号が長すぎます（最大{SHELF_NUMBER_MAX_LENGTH}文字）"

    if not SHELF_NUMBER_PATTERN.fullmatch(normalized):
        return False, normalized, "棚番号が『数字-数字-数字』の形式ではありません"

    return True, normalized, ""


def notify_shelf_validation_error(lane_label, raw_value, reason):
    """登録を止めたことをログ・カメラ画面・警告音で作業者へ知らせる。"""
    display_value = normalize_shelf_number(raw_value) or "空欄"
    logging.error(
        f"❌ [{lane_label}] 棚番号『{display_value}』は登録しません。{reason}。"
        " 画面を確認して、もう一度F12を押してください。"
    )

    notify_lane_status(
        lane_label,
        "ERROR",
        f"Invalid shelf: {display_value}",
        sound_kind="error" if OCR_ERROR_BEEP_ENABLED else None,
        duration=OPERATION_ERROR_DISPLAY_SECONDS,
    )


# 💡 OCR共通前処理（タイトル判定など従来OCR用）
def preprocess_for_ocr(pil_img):
    img = np.array(pil_img)
    gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)

    # 画像を2倍に拡大し、小さな文字をクッキリさせる
    gray = cv2.resize(gray, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)

    # 明るさに合わせて白黒化
    _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    # Tesseractが読みやすい「白背景・黒文字」へ寄せる
    white_pixels = cv2.countNonZero(thresh)
    black_pixels = thresh.size - white_pixels
    if black_pixels > white_pixels:
        thresh = cv2.bitwise_not(thresh)

    return thresh


def preprocess_green_terminal_ocr(pil_img, scale=4):
    """黒背景＋緑文字のAS/400画面から緑文字だけを強調してOCR用画像を作る。"""
    rgb = np.array(pil_img)
    if rgb.ndim != 3 or rgb.shape[2] < 3:
        return preprocess_for_ocr(pil_img)

    rgb = rgb[:, :, :3]
    hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV)

    # 主な緑色域をHSVで抽出。画面の発光・撮影条件差を考慮してやや広めに取る。
    hsv_mask = cv2.inRange(
        hsv,
        np.array([30, 35, 45], dtype=np.uint8),
        np.array([105, 255, 255], dtype=np.uint8),
    )

    # 低彩度になった緑文字も拾えるよう「G成分がR/Bより明確に強い」画素も追加する。
    r = rgb[:, :, 0].astype(np.int16)
    g = rgb[:, :, 1].astype(np.int16)
    b = rgb[:, :, 2].astype(np.int16)
    dominance_mask = (
        (g >= 55)
        & (g >= r + 18)
        & (g >= b + 10)
    ).astype(np.uint8) * 255

    mask = cv2.bitwise_or(hsv_mask, dominance_mask)

    # 点欠けを埋め、細い数字を少し太らせる。
    close_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, close_kernel, iterations=1)
    mask = cv2.dilate(mask, np.ones((2, 2), dtype=np.uint8), iterations=1)

    # Tesseract向けに「白背景・黒文字」へ反転し、大きく拡大する。
    processed = cv2.bitwise_not(mask)
    processed = cv2.copyMakeBorder(
        processed, 10, 10, 10, 10, cv2.BORDER_CONSTANT, value=255
    )
    processed = cv2.resize(
        processed,
        None,
        fx=scale,
        fy=scale,
        interpolation=cv2.INTER_NEAREST,
    )
    return processed


def _candidate_from_ocr_text(raw_text):
    """OCR文字列から従来ルールで棚番号候補を組み立てる。"""
    text = normalize_shelf_number(raw_text)
    if SHELF_NUMBER_PATTERN.fullmatch(text):
        return text

    numbers = re.findall(r'[0-9]+', text)
    if len(numbers) == 3:
        return f"{numbers[0]}-{numbers[1]}-{numbers[2]}"
    if len(numbers) == 2 and len(numbers[1]) >= 2:
        return f"{numbers[0]}-{numbers[1][0]}-{numbers[1][1:]}"
    if len(numbers) == 1:
        digits = numbers[0]
        if len(digits) == 3:    # 456 -> 4-5-6
            return f"{digits[0]}-{digits[1]}-{digits[2]}"
        if len(digits) == 4:    # 4520 -> 4-5-20
            return f"{digits[0]}-{digits[1]}-{digits[2:]}"
        if len(digits) >= 5:    # 41010 -> 4-10-10
            return f"{digits[0]}-{digits[1:3]}-{digits[3:]}"
    return ""


def _ocr_green_three_parts(screenshot):
    """棚番号領域を横3分割し、列・連・段を個別OCRする。成功時だけ候補を返す。"""
    rgb = np.array(screenshot)
    if rgb.ndim != 3 or rgb.shape[1] < 90:
        return "", []

    width = rgb.shape[1]
    edges = [0, width // 3, (width * 2) // 3, width]
    values = []
    raw_parts = []

    for index in range(3):
        left, right = edges[index], edges[index + 1]
        # 分割境界に文字が触れても欠けにくいよう、左右を少し重ねる。
        overlap = max(3, width // 60)
        left = max(0, left - overlap)
        right = min(width, right + overlap)

        crop = screenshot.crop((left, 0, right, screenshot.height))
        processed = preprocess_green_terminal_ocr(crop, scale=5)
        raw = pytesseract.image_to_string(
            processed,
            config=r'--oem 3 --psm 8 -c tessedit_char_whitelist=0123456789',
        ).strip()
        digits = ''.join(re.findall(r'[0-9]+', raw))
        raw_parts.append(raw)
        values.append(digits)

    if all(values):
        candidate = f"{values[0]}-{values[1]}-{values[2]}"
        is_valid, normalized, _ = validate_shelf_number(candidate)
        if is_valid:
            return normalized, raw_parts

    return "", raw_parts


def is_target_screen(window):
    try:
        abs_bbox = get_absolute_bbox(window, BBOX_TITLE_RELATIVE, padding_x=5, padding_y=5)
        screenshot = pyautogui.screenshot(region=abs_bbox)
        processed_img = preprocess_for_ocr(screenshot)
        text = pytesseract.image_to_string(processed_img, lang='jpn', config='--oem 3 --psm 7')
        if TARGET_SCREEN_KEYWORD in text and EXCLUDE_KEYWORD not in text: return True
        return False
    except Exception: return False


def extract_shelf_number(window):
    try:
        abs_bbox = get_absolute_bbox(window, BBOX_SHELF_RELATIVE, padding_x=15, padding_y=5)
        screenshot = pyautogui.screenshot(region=abs_bbox)

        # 方式A: 黒背景＋緑文字に合わせ、列・連・段を3領域に分けて個別OCRする。
        split_candidate, split_raw = _ocr_green_three_parts(screenshot)
        if split_candidate:
            logging.info(
                f"  [🔍 棚番号OCR/緑3分割] 生データ: {split_raw} -> 「{split_candidate}」"
            )
            return split_candidate

        logging.info(
            f"  [🔍 棚番号OCR/緑3分割] 確定できず。生データ: {split_raw}。次の方式を試します。"
        )

        # 方式B: 棚番号領域全体から緑文字だけを抽出してOCRする。
        green_processed = preprocess_green_terminal_ocr(screenshot, scale=4)
        green_raw = pytesseract.image_to_string(
            green_processed,
            config=r'--oem 3 --psm 7 -c tessedit_char_whitelist=0123456789-',
        ).strip()
        green_candidate = _candidate_from_ocr_text(green_raw)
        green_valid, green_normalized, green_reason = validate_shelf_number(green_candidate)
        logging.info(
            f"  [🔍 棚番号OCR/緑全体] 生データ: 「{green_raw}」 / 候補: 「{green_candidate or '空欄'}」"
        )
        if green_valid:
            logging.info(f"  [✅ 棚番号OCR/緑全体] 確定値: 「{green_normalized}」")
            return green_normalized

        # 方式C: 緑抽出が失敗した場合のみ、改善10までの従来グレースケールOCRへ戻す。
        processed_img = preprocess_for_ocr(screenshot)
        raw_text = pytesseract.image_to_string(
            processed_img,
            config=r'--oem 3 --psm 7 -c tessedit_char_whitelist=0123456789-',
        ).strip()
        candidate = _candidate_from_ocr_text(raw_text)
        is_valid, normalized_shelf, reason = validate_shelf_number(candidate)

        logging.info(
            f"  [🔍 棚番号OCR/従来方式] 生データ: 「{raw_text}」 / 候補: 「{candidate or '空欄'}」"
        )
        if is_valid:
            logging.info(f"  [✅ 棚番号OCR/従来方式] 確定値: 「{normalized_shelf}」")
            return normalized_shelf

        logging.warning(
            f"⚠️ [棚番号OCR] 3方式すべてで棚番号を確定できませんでした。"
            f" 緑全体: {green_reason} / 従来方式: {reason}"
        )
        return "読取エラー"

    except Exception as e:
        logging.error(f"❌ [棚番号OCR] 読取処理でエラーが発生しました: {e}")
        return "システムエラー"

def ensure_google_clients():
    """保存済み認証を使い、通信復旧後にGoogle接続を自動再構築する。"""
    global creds, drive_service, gc

    try:
        # 起動時に通信できなかった場合でも、保存済みトークンから再開します。
        if creds is None and os.path.exists(token_path):
            with open(token_path, 'rb') as token_file:
                creds = pickle.load(token_file)

        if not creds:
            logging.warning("⚠️ Google認証情報がないため送信できません。")
            return False

        if not creds.valid:
            if creds.expired and creds.refresh_token:
                logging.info("🔄 Google APIの認証期限切れを検知。自動更新します...")
                creds.refresh(Request())
                with open(token_path, 'wb') as token_file:
                    pickle.dump(creds, token_file)
                drive_service = None
                gc = None
            else:
                logging.warning("⚠️ Google認証情報が無効です。再認証が必要です。")
                return False

        # 起動時の一時的な通信エラーで初期化できなかった場合に再構築します。
        if drive_service is None:
            drive_service = build('drive', 'v3', credentials=creds)
        if gc is None:
            gc = gspread.authorize(creds)

        return bool(drive_service and gc)

    except Exception as e:
        logging.error(f"⚠️ Google API接続の再構築に失敗しました: {e}")
        drive_service = None
        gc = None
        return False


def save_pending_upload(lane_id, shelf_number, file_path, file_name, folder_id, sheet_name, failure_reason):
    """送信に失敗した写真と再送用情報をローカルへ安全に保管する。"""
    is_valid, normalized_shelf, validation_error = validate_shelf_number(shelf_number)
    if not is_valid:
        logging.error(
            f"❌ [未送信保存停止] 不正な棚番号のためキューへ保存しません: "
            f"{shelf_number} / {validation_error}"
        )
        return False
    shelf_number = normalized_shelf

    if not os.path.exists(file_path):
        logging.error(f"❌ [未送信保存失敗] 元画像が見つかりません: {file_path}")
        return False

    queue_id = f"{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}_{uuid.uuid4().hex[:8]}"
    extension = os.path.splitext(file_name)[1] or '.jpg'
    pending_image_name = f"{queue_id}{extension.lower()}"
    pending_json_name = f"{queue_id}.json"
    pending_image_path = os.path.join(PENDING_DIR, pending_image_name)
    pending_json_path = os.path.join(PENDING_DIR, pending_json_name)
    pending_json_temp_path = f"{pending_json_path}.tmp"

    created_at = datetime.now()
    metadata = {
        "queue_id": queue_id,
        "status": "pending",
        "created_at": created_at.isoformat(timespec='microseconds'),
        "attempt_count": 0,
        "last_attempt_at": None,
        # 保存直後から再送対象にします。常駐スレッド側の初回待機は5秒です。
        "next_retry_at": created_at.isoformat(timespec='microseconds'),
        "last_error": str(failure_reason),
        "lane_id": lane_id,
        "shelf_number": str(shelf_number),
        "sheet_name": sheet_name,
        "drive_folder_id": folder_id,
        "remote_file_name": file_name,
        "local_image_name": pending_image_name,
    }

    try:
        os.makedirs(PENDING_DIR, exist_ok=True)

        # 元画像を残したまま未送信フォルダへコピーし、
        # メタデータまで正常に保存できた後で元画像を削除します。
        shutil.copy2(file_path, pending_image_path)
        with open(pending_json_temp_path, 'w', encoding='utf-8') as metadata_file:
            json.dump(metadata, metadata_file, ensure_ascii=False, indent=2)
        os.replace(pending_json_temp_path, pending_json_path)
        os.remove(file_path)

        logging.warning(
            f"📥 [未送信として保管] 棚番号 {shelf_number} の写真を "
            f"{PENDING_DIR} に保存しました。"
        )
        return True

    except Exception as e:
        logging.error(f"❌ [未送信保存失敗] 写真を保管できませんでした: {e}")

        # 不完全な一時JSONだけを削除します。
        if os.path.exists(pending_json_temp_path):
            try:
                os.remove(pending_json_temp_path)
            except OSError:
                pass

        # 元画像は削除しません。手動回収できる状態を優先します。
        return False


def _escape_drive_query_value(value):
    """Google Drive検索式へ入れる文字列を安全にエスケープする。"""
    return str(value).replace("\\", "\\\\").replace("'", "\\'")


def _find_existing_drive_images(shelf_number, folder_id):
    """新規アップロード前に、同じ棚の既存画像を一覧化する。削除はまだ行わない。"""
    escaped_shelf = _escape_drive_query_value(f"{shelf_number}_")
    escaped_folder = _escape_drive_query_value(folder_id)
    query = (
        f"name contains '{escaped_shelf}' and "
        f"'{escaped_folder}' in parents and trashed=false"
    )
    results = drive_service.files().list(
        q=query,
        fields="files(id, name)",
    ).execute()

    prefix = f"{shelf_number}_"
    return [
        item for item in results.get('files', [])
        if str(item.get('name', '')).startswith(prefix)
    ]


def _find_existing_sheet_rows(sheet, shelf_number):
    """新規行の追加前に、同じ棚番号を持つ既存行番号を記録する。"""
    shelf_col_values = sheet.col_values(4)
    row_numbers = []

    for row_number, cell_value in enumerate(shelf_col_values, start=1):
        if normalize_shelf_number(cell_value) == shelf_number:
            row_numbers.append(row_number)

    return row_numbers


def _rollback_new_drive_file(file_id, file_name):
    """スプレッドシート更新前に失敗した場合、新規画像だけを取り消す。"""
    if not file_id:
        return True

    try:
        drive_service.files().delete(fileId=file_id).execute()
        logging.info(f"↩️ [ロールバック] 新規画像を取り消しました: {file_name}")
        return True
    except Exception as e:
        # 古い画像と古い行は残っているため、ここで運用データを失うことはありません。
        logging.error(
            f"🚨 [ロールバック失敗] 新規画像を削除できませんでした。"
            f"孤立画像として確認してください: {file_name} / {e}"
        )
        return False


def _make_current_record_key(lane_id, shelf_number):
    """AppSheetの現在表示用レコードで使う、棚ごとの固定キーを作る。"""
    return f"{str(lane_id).strip()}|{str(shelf_number).strip()}"


def _find_sheet_rows_by_key(sheet, record_key):
    """A列の固定キーが一致する行番号を返す。"""
    key_col_values = sheet.col_values(1)
    return [
        row_number
        for row_number, cell_value in enumerate(key_col_values, start=1)
        if str(cell_value).strip() == record_key
    ]


def _sheet_row_matches_current(sheet, row_number, record_key, lane_id, shelf_number, image_path):
    """更新応答が不明な場合、対象行が期待した最新値になっているか確認する。"""
    try:
        rows = sheet.get(f"A{row_number}:E{row_number}")
        if not rows:
            return False

        row = list(rows[0]) + [""] * 5
        return (
            str(row[0]).strip() == record_key
            and str(row[2]).strip() == str(lane_id).strip()
            and normalize_shelf_number(row[3]) == shelf_number
            and str(row[4]).strip() == image_path
        )
    except Exception as e:
        logging.warning(
            f"⚠️ 固定キー更新結果をスプレッドシートで再確認できませんでした "
            f"（{row_number}行目）: {e}"
        )
        return False


def _cleanup_duplicate_sheet_rows(sheet, row_numbers, keep_row_number, shelf_number):
    """固定キーで使う1行を残し、同じ棚の重複行だけを削除する。"""
    failed = 0
    duplicate_rows = [
        row_number
        for row_number in sorted(set(row_numbers), reverse=True)
        if row_number != keep_row_number
    ]

    for row_number in duplicate_rows:
        try:
            sheet.delete_rows(row_number)
            logging.info(
                f"🧹 [固定キー整理] スプシの重複行を削除しました "
                f"（{row_number}行目: {shelf_number}）"
            )
        except Exception as e:
            failed += 1
            logging.warning(
                f"⚠️ [固定キー整理] スプシの重複行を削除できませんでした "
                f"（{row_number}行目: {shelf_number}）: {e}"
            )
    return failed


def _cleanup_old_drive_images(existing_images, shelf_number):
    """スプレッドシートの最新値保存成功後に限り、旧画像を削除する。"""
    failed = 0
    for item in existing_images:
        file_id = item.get('id')
        file_name = item.get('name', '名前不明')
        if not file_id:
            failed += 1
            logging.warning(
                f"⚠️ [更新後整理] Drive旧画像のIDがありません: {file_name}"
            )
            continue

        try:
            drive_service.files().delete(fileId=file_id).execute()
            logging.info(f"🗑️ [更新後整理] Drive旧画像を削除しました: {file_name}")
        except Exception as e:
            failed += 1
            logging.warning(
                f"⚠️ [更新後整理] Drive旧画像を削除できませんでした: "
                f"{file_name} / {e}"
            )
    return failed


def _upload_and_sync_core(lane_id, shelf_number, file_path, file_name, folder_id, sheet_name):
    # Driveやスプレッドシートの既存データを操作する前に、棚番号を最後に確認します。
    is_valid, normalized_shelf, validation_error = validate_shelf_number(shelf_number)
    if not is_valid:
        logging.error(
            f"❌ [Google送信停止] 不正な棚番号のため送信しません: "
            f"{shelf_number} / {validation_error}"
        )
        return False
    shelf_number = normalized_shelf

    if not os.path.exists(file_path):
        logging.error(f"❌ [Google送信停止] 送信する画像が見つかりません: {file_path}")
        return False

    if not ensure_google_clients():
        return False

    new_drive_file_id = None
    sheet_commit_succeeded = False
    sheet_write_attempted = False

    try:
        # ==========================================
        # 1. 現在行と旧画像を確認する（まだ削除しない）
        # ==========================================
        sheet = gc.open_by_url(SPREADSHEET_URL).worksheet(sheet_name)
        record_key = _make_current_record_key(lane_id, shelf_number)
        shelf_rows = _find_existing_sheet_rows(sheet, shelf_number)
        key_rows = _find_sheet_rows_by_key(sheet, record_key)
        existing_drive_images = _find_existing_drive_images(shelf_number, folder_id)

        # すでに固定キー化済みの行があればそれを優先します。
        # 改善5以前のUUID行しかない場合は、同じ棚の一番下の行をそのまま固定キー行へ移行します。
        if key_rows:
            target_row_number = max(key_rows)
        elif shelf_rows:
            target_row_number = max(shelf_rows)
        else:
            target_row_number = None

        all_same_shelf_rows = sorted(set(shelf_rows + key_rows))

        logging.info(
            f"🔎 [固定キー更新] 棚番号 {shelf_number}: "
            f"現在候補 {len(all_same_shelf_rows)}行 / 旧画像 {len(existing_drive_images)}件を確認"
        )

        # ==========================================
        # 2. 新しい写真を先にアップロードする
        # ==========================================
        file_metadata = {'name': file_name, 'parents': [folder_id]}
        media = MediaFileUpload(file_path, mimetype='image/jpeg')
        upload_result = drive_service.files().create(
            body=file_metadata,
            media_body=media,
            fields='id, name',
        ).execute()
        new_drive_file_id = upload_result.get('id')
        if not new_drive_file_id:
            raise RuntimeError('Google Driveから新規画像のファイルIDが返されませんでした')

        if "3" in sheet_name:
            image_path = f"3号残棚写真/{file_name}"
        else:
            image_path = f"4号残棚写真/{file_name}"

        logging.info(
            f"☁️ [固定キー更新] 新しい写真を先に保存しました: {file_name}"
        )

        # ==========================================
        # 3. 棚ごとの固定キーで、同じ現在行を直接更新する
        # ==========================================
        safe_shelf_number = f"'{shelf_number}"
        row_data = [
            record_key,
            datetime.now().strftime("%Y/%m/%d %H:%M:%S"),
            lane_id,
            safe_shelf_number,
            image_path,
        ]

        if target_row_number is None:
            # 初回だけは新しい行を作ります。次回以降はこの同じ行を更新します。
            try:
                sheet_write_attempted = True
                sheet.append_row(row_data)

                # append_row後の行番号を固定キーから取得します。
                key_rows_after = _find_sheet_rows_by_key(sheet, record_key)
                if not key_rows_after:
                    raise RuntimeError('固定キー行を追加後に確認できませんでした')
                target_row_number = max(key_rows_after)
                sheet_commit_succeeded = _sheet_row_matches_current(
                    sheet,
                    target_row_number,
                    record_key,
                    lane_id,
                    shelf_number,
                    image_path,
                )
                if not sheet_commit_succeeded:
                    raise RuntimeError('追加した固定キー行の内容を確認できませんでした')
            except Exception as append_error:
                # 応答だけ失敗した可能性があるため、固定キーと画像パスで再確認します。
                key_rows_after = _find_sheet_rows_by_key(sheet, record_key)
                verified_row = None
                for row_number in reversed(key_rows_after):
                    if _sheet_row_matches_current(
                        sheet,
                        row_number,
                        record_key,
                        lane_id,
                        shelf_number,
                        image_path,
                    ):
                        verified_row = row_number
                        break

                if verified_row is not None:
                    target_row_number = verified_row
                    sheet_commit_succeeded = True
                    logging.warning(
                        f"⚠️ [固定キー更新] 追加応答はエラーでしたが、"
                        f"固定キー行の保存を確認できました: {record_key} / {append_error}"
                    )
                else:
                    # 書き込みの成否を確認できない場合、新規Drive画像は消しません。
                    # 実際には行更新済みだった場合に、AppSheetの参照画像を消す事故を防ぎます。
                    logging.error(
                        f"⚠️ [固定キー更新中断] 固定キー行の追加結果を確認できません。"
                        f"旧データと新規Drive画像を残したまま未送信へ回します: {append_error}"
                    )
                    return False
        else:
            try:
                sheet_write_attempted = True
                sheet.update(
                    range_name=f"A{target_row_number}:E{target_row_number}",
                    values=[row_data],
                )
                sheet_commit_succeeded = _sheet_row_matches_current(
                    sheet,
                    target_row_number,
                    record_key,
                    lane_id,
                    shelf_number,
                    image_path,
                )
                if not sheet_commit_succeeded:
                    raise RuntimeError('更新した固定キー行の内容を確認できませんでした')
            except Exception as update_error:
                # 通信切断の瞬間によっては、応答だけ失敗し実際には更新済みの場合があります。
                if _sheet_row_matches_current(
                    sheet,
                    target_row_number,
                    record_key,
                    lane_id,
                    shelf_number,
                    image_path,
                ):
                    sheet_commit_succeeded = True
                    logging.warning(
                        f"⚠️ [固定キー更新] 更新応答はエラーでしたが、"
                        f"{target_row_number}行目の保存を確認できました: {update_error}"
                    )
                else:
                    logging.error(
                        f"⚠️ [固定キー更新中断] {target_row_number}行目の更新結果を確認できません。"
                        f"旧データと新規Drive画像を残したまま未送信へ回します: {update_error}"
                    )
                    return False

        logging.info(
            f"📊 [固定キー更新] {target_row_number}行目を最新化しました。"
            f"キー: {record_key} / AppSheet連携パス: {image_path}"
        )

        # ==========================================
        # 4. 最新行の保存成功後に、重複行と旧画像を整理する
        # ==========================================
        # 改善5までの旧UUID行や、過去の整理失敗で重複が残っている場合だけ削除します。
        rows_to_cleanup = sorted(set(all_same_shelf_rows + _find_sheet_rows_by_key(sheet, record_key)))
        sheet_cleanup_failures = _cleanup_duplicate_sheet_rows(
            sheet,
            rows_to_cleanup,
            target_row_number,
            shelf_number,
        )
        drive_cleanup_failures = _cleanup_old_drive_images(
            existing_drive_images,
            shelf_number,
        )

        cleanup_failures = sheet_cleanup_failures + drive_cleanup_failures
        if cleanup_failures:
            logging.warning(
                f"⚠️ [固定キー更新完了・整理残り] 最新データは保存済みです。"
                f"旧データの整理に{cleanup_failures}件失敗しました。"
                " 次回の同棚更新時にも整理を再試行します。"
            )
        else:
            logging.info(
                f"✅ [固定キー更新完了] 棚番号 {shelf_number} を同じ行で更新しました。"
            )

        return True

    except Exception as e:
        if sheet_commit_succeeded:
            # 固定キー行が最新化済みなら、後処理だけの例外で自動再送へ戻さない。
            logging.warning(
                f"⚠️ [固定キー更新完了・後処理エラー] 最新データは保存済みです。"
                f"旧データ整理だけを次回更新時へ持ち越します: {e}"
            )
            return True

        # スプレッドシート書き込みをまだ試していない段階の失敗なら、
        # 新規画像を取り消しても現在行が新画像を参照している可能性はありません。
        if new_drive_file_id and not sheet_write_attempted:
            _rollback_new_drive_file(new_drive_file_id, file_name)

        # 書き込み試行後は、応答だけ失敗して実際には更新済みの可能性があるため、
        # 新規Drive画像を削除せず未送信へ回します。
        logging.error(f"⚠️ [通信エラー] Google固定キー更新に失敗しました: {e}")
        return False

def _write_pending_metadata(metadata_path, metadata):
    """未送信メタデータを一時ファイル経由で安全に更新する。"""
    temp_path = f"{metadata_path}.tmp"
    try:
        with open(temp_path, 'w', encoding='utf-8') as metadata_file:
            json.dump(metadata, metadata_file, ensure_ascii=False, indent=2)
        os.replace(temp_path, metadata_path)
        return True
    except Exception as e:
        logging.error(f"❌ [再送情報更新失敗] {metadata_path}: {e}")
        if os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except OSError:
                pass
        return False


def _load_pending_metadata(metadata_path):
    """未送信JSONを読み込む。壊れたJSONは削除せず、その場に残す。"""
    try:
        with open(metadata_path, 'r', encoding='utf-8') as metadata_file:
            metadata = json.load(metadata_file)
        if not isinstance(metadata, dict):
            raise ValueError('JSONの内容が辞書形式ではありません')
        return metadata
    except Exception as e:
        logging.error(f"❌ [再送情報読込失敗] {metadata_path}: {e}")
        return None


def _pending_image_path(metadata):
    image_name = os.path.basename(str(metadata.get('local_image_name', '')))
    if not image_name:
        return None
    return os.path.join(PENDING_DIR, image_name)


def _remove_pending_pair(metadata_path, metadata, reason):
    """送信済み・旧版となった未送信画像とJSONを削除する。"""
    image_path = _pending_image_path(metadata)
    cleanup_ok = True

    if image_path and os.path.exists(image_path):
        try:
            os.remove(image_path)
        except OSError as e:
            cleanup_ok = False
            logging.warning(f"⚠️ [{reason}] 画像を削除できませんでした: {e}")

    if cleanup_ok and os.path.exists(metadata_path):
        try:
            os.remove(metadata_path)
        except OSError as e:
            cleanup_ok = False
            logging.warning(f"⚠️ [{reason}] JSONを削除できませんでした: {e}")

    if cleanup_ok:
        logging.info(
            f"🧹 [{reason}] 未送信データを整理しました: "
            f"棚番号 {metadata.get('shelf_number', '不明')}"
        )
    return cleanup_ok


def _discard_older_pending_for_shelf(lane_id, shelf_number, exclude_queue_id=None):
    """
    同じ号機・棚番号の古い未送信データを整理する。

    現行システムは棚ごとに最新写真だけを表示するため、より新しい写真の
    送信成功後に古い未送信写真が再送され、表示を巻き戻すことを防ぎます。
    """
    try:
        metadata_names = sorted(
            name for name in os.listdir(PENDING_DIR)
            if name.lower().endswith('.json')
        )
    except OSError as e:
        logging.warning(f"⚠️ 未送信フォルダを確認できませんでした: {e}")
        return

    target_lane = str(lane_id)
    target_shelf = str(shelf_number).replace("'", '').strip()

    for metadata_name in metadata_names:
        metadata_path = os.path.join(PENDING_DIR, metadata_name)
        metadata = _load_pending_metadata(metadata_path)
        if not metadata:
            continue

        if exclude_queue_id and metadata.get('queue_id') == exclude_queue_id:
            continue

        queued_lane = str(metadata.get('lane_id', ''))
        queued_shelf = str(metadata.get('shelf_number', '')).replace("'", '').strip()
        if queued_lane == target_lane and queued_shelf == target_shelf:
            _remove_pending_pair(metadata_path, metadata, '旧版未送信データ整理')


def _parse_iso_datetime(value):
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value))
    except (TypeError, ValueError):
        return None


def _retry_delay_seconds(attempt_count):
    # attempt_countは今回の再送を含む回数です。
    index = min(max(int(attempt_count) - 1, 0), len(PENDING_RETRY_BACKOFF_SECONDS) - 1)
    return PENDING_RETRY_BACKOFF_SECONDS[index]


def _pending_record_order(metadata, metadata_path):
    """作成日時が同じ場合もqueue_idで新旧を確実に判定する。"""
    created_at = _parse_iso_datetime(metadata.get('created_at')) or datetime.min
    queue_id = str(metadata.get('queue_id') or os.path.basename(metadata_path))
    return created_at, queue_id


def _is_newest_pending_for_shelf(metadata_path, metadata):
    """同じ号機・棚番号に、現在のデータより新しい未送信写真がないか確認する。"""
    target_key = (
        str(metadata.get('lane_id', '')),
        str(metadata.get('shelf_number', '')).replace("'", '').strip(),
    )
    target_order = _pending_record_order(metadata, metadata_path)

    try:
        metadata_names = (
            name for name in os.listdir(PENDING_DIR)
            if name.lower().endswith('.json')
        )
    except OSError as e:
        logging.warning(f"⚠️ 未送信フォルダを確認できませんでした: {e}")
        return True

    for metadata_name in metadata_names:
        other_path = os.path.join(PENDING_DIR, metadata_name)
        if os.path.abspath(other_path) == os.path.abspath(metadata_path):
            continue

        other = _load_pending_metadata(other_path)
        if not other or str(other.get('status', 'pending')) not in {'pending', 'retrying'}:
            continue

        other_key = (
            str(other.get('lane_id', '')),
            str(other.get('shelf_number', '')).replace("'", '').strip(),
        )
        if other_key == target_key and _pending_record_order(other, other_path) > target_order:
            return False

    return True


def upload_and_sync(lane_id, shelf_number, file_path, file_name, folder_id, sheet_name):
    """従来互換用。Google連携を必ず1件ずつ実行する。"""
    with sync_operation_lock:
        return _upload_and_sync_core(
            lane_id,
            shelf_number,
            file_path,
            file_name,
            folder_id,
            sheet_name,
        )


def _retry_one_pending(metadata_path):
    """未送信データ1件を再送する。呼び出し元で同期ロックを保持する。"""
    if not os.path.exists(metadata_path):
        return False

    metadata = _load_pending_metadata(metadata_path)
    if not metadata:
        return False

    status = str(metadata.get('status', 'pending'))
    if status == 'completed':
        _remove_pending_pair(metadata_path, metadata, '送信済みデータ整理')
        return False
    if status not in {'pending', 'retrying'}:
        return False

    is_valid, normalized_shelf, validation_error = validate_shelf_number(
        metadata.get('shelf_number')
    )
    if not is_valid:
        metadata['status'] = 'error_invalid_shelf'
        metadata['last_error'] = f"不正な棚番号: {validation_error}"
        _write_pending_metadata(metadata_path, metadata)
        logging.error(
            f"❌ [自動再送停止] 棚番号が不正なため再送しません: "
            f"{metadata.get('shelf_number')} / {metadata_path}"
        )
        return False
    metadata['shelf_number'] = normalized_shelf

    # 一覧を作った直後に通常撮影が失敗して、さらに新しい未送信写真が
    # 追加された場合でも、古い写真を後から表示へ戻さないよう再確認します。
    if not _is_newest_pending_for_shelf(metadata_path, metadata):
        return False

    now = datetime.now()
    next_retry_at = _parse_iso_datetime(metadata.get('next_retry_at'))
    if next_retry_at and now < next_retry_at:
        return False

    required_fields = (
        'lane_id',
        'shelf_number',
        'sheet_name',
        'drive_folder_id',
        'remote_file_name',
        'local_image_name',
    )
    missing_fields = [field for field in required_fields if not metadata.get(field)]
    if missing_fields:
        metadata['status'] = 'error_invalid_metadata'
        metadata['last_error'] = f"必要項目不足: {', '.join(missing_fields)}"
        _write_pending_metadata(metadata_path, metadata)
        logging.error(
            f"❌ [自動再送停止] 必要項目が不足しています: {metadata_path}"
        )
        return False

    image_path = _pending_image_path(metadata)
    if not image_path or not os.path.exists(image_path):
        metadata['status'] = 'error_missing_image'
        metadata['last_error'] = '再送対象の画像ファイルが見つかりません'
        _write_pending_metadata(metadata_path, metadata)
        logging.error(
            f"❌ [自動再送停止] 画像ファイルが見つかりません: {image_path}"
        )
        return False

    attempt_count = int(metadata.get('attempt_count', 0)) + 1
    metadata['status'] = 'retrying'
    metadata['attempt_count'] = attempt_count
    metadata['last_attempt_at'] = now.isoformat(timespec='seconds')
    if not _write_pending_metadata(metadata_path, metadata):
        return False

    notify_lane_status(
        metadata['lane_id'],
        "RETRY",
        f"Retry {metadata['shelf_number']} ({attempt_count})",
        duration=0,
    )
    logging.info(
        f"🔄 [自動再送] 棚番号 {metadata['shelf_number']} を再送します "
        f"（{attempt_count}回目）"
    )

    sync_success = _upload_and_sync_core(
        metadata['lane_id'],
        metadata['shelf_number'],
        image_path,
        metadata['remote_file_name'],
        metadata['drive_folder_id'],
        metadata['sheet_name'],
    )

    if sync_success:
        metadata['status'] = 'completed'
        metadata['completed_at'] = datetime.now().isoformat(timespec='seconds')
        metadata['last_error'] = ''

        # 完了状態を先に保存しておくことで、画像削除後にアプリが終了しても
        # 次回起動時は再送せず、残ったJSONだけを整理できます。
        if _write_pending_metadata(metadata_path, metadata):
            _discard_older_pending_for_shelf(
                metadata['lane_id'],
                metadata['shelf_number'],
                exclude_queue_id=metadata.get('queue_id'),
            )
            _remove_pending_pair(metadata_path, metadata, '自動再送成功')

        logging.info(
            f"✅ [自動再送成功] 棚番号 {metadata['shelf_number']} の送信が完了しました。"
        )
        notify_lane_status(
            metadata['lane_id'],
            "SUCCESS",
            f"Auto retry OK: {metadata['shelf_number']}",
            sound_kind="success" if AUTO_RETRY_SUCCESS_SOUND_ENABLED else None,
        )
        return True

    retry_delay = _retry_delay_seconds(attempt_count)
    metadata['status'] = 'pending'
    metadata['last_error'] = 'Google Driveまたはスプレッドシートへの自動再送に失敗'
    metadata['next_retry_at'] = (
        datetime.now() + timedelta(seconds=retry_delay)
    ).isoformat(timespec='seconds')
    _write_pending_metadata(metadata_path, metadata)
    logging.warning(
        f"⚠️ [自動再送失敗] 棚番号 {metadata['shelf_number']} は "
        f"約{retry_delay}秒後に再試行します。"
    )
    # 定期再送のたびに警告音を鳴らすと作業を妨げるため、画面表示だけ更新します。
    notify_lane_status(
        metadata['lane_id'],
        "PENDING",
        f"Retry later: {metadata['shelf_number']}",
        duration=OPERATION_STATUS_DISPLAY_SECONDS,
    )
    return True


def retry_pending_uploads_once():
    """未送信フォルダを1回確認し、期限を迎えたデータを再送する。"""
    try:
        metadata_paths = sorted(
            os.path.join(PENDING_DIR, name)
            for name in os.listdir(PENDING_DIR)
            if name.lower().endswith('.json')
        )
    except OSError as e:
        logging.warning(f"⚠️ 未送信フォルダを確認できませんでした: {e}")
        return

    if not metadata_paths:
        return

    # 同じ号機・棚番号が複数ある場合は、最も新しい写真だけを再送候補にします。
    # 古い写真は、新しい写真の送信成功後に整理します。
    newest_by_shelf = {}
    completed_paths = []

    for metadata_path in metadata_paths:
        metadata = _load_pending_metadata(metadata_path)
        if not metadata:
            continue

        status = str(metadata.get('status', 'pending'))
        if status == 'completed':
            completed_paths.append(metadata_path)
            continue
        if status not in {'pending', 'retrying'}:
            continue

        key = (
            str(metadata.get('lane_id', '')),
            str(metadata.get('shelf_number', '')).replace("'", '').strip(),
        )
        record_order = _pending_record_order(metadata, metadata_path)
        current = newest_by_shelf.get(key)
        if current is None or record_order > current[0]:
            newest_by_shelf[key] = (record_order, metadata_path)

    # 送信済み状態で残ったファイルは、ネット通信を行わず先に整理します。
    for metadata_path in completed_paths:
        with sync_operation_lock:
            if os.path.exists(metadata_path):
                metadata = _load_pending_metadata(metadata_path)
                if metadata and metadata.get('status') == 'completed':
                    _remove_pending_pair(metadata_path, metadata, '送信済みデータ整理')

    candidates = sorted(
        newest_by_shelf.values(),
        key=lambda item: item[0],
    )

    attempted = 0
    for _, metadata_path in candidates:
        if attempted >= PENDING_RETRY_MAX_PER_CYCLE:
            break

        with sync_operation_lock:
            # 通常撮影が先に成功してキューを整理した可能性があるため、
            # ロック取得後に存在確認とJSON再読込を行います。
            did_attempt = _retry_one_pending(metadata_path)
        if did_attempt:
            attempted += 1


def pending_retry_worker():
    """バックグラウンドで未送信データを監視し、自動再送する。"""
    logging.info(
        "🔁 未送信データの自動再送を開始しました "
        f"（確認間隔: {PENDING_RETRY_SCAN_SECONDS}秒）"
    )

    if retry_stop_event.wait(PENDING_RETRY_INITIAL_DELAY_SECONDS):
        return

    while not retry_stop_event.is_set():
        try:
            retry_pending_uploads_once()
        except Exception as e:
            logging.error(f"❌ 未送信データの自動再送処理でエラーが発生しました: {e}")

        retry_stop_event.wait(PENDING_RETRY_SCAN_SECONDS)


def capture_process(lane_label, lane_id, frame, shelf_number, folder_id, sheet_name):
    is_valid, normalized_shelf, validation_error = validate_shelf_number(shelf_number)
    if not is_valid:
        notify_shelf_validation_error(lane_label, shelf_number, validation_error)
        return
    shelf_number = normalized_shelf

    notify_lane_status(lane_id, "CAPTURE", f"Shelf {shelf_number}", duration=0)
    logging.info(f"📸 [{lane_label}] 返却処理スタート！ (棚番号: {shelf_number})")
    if frame is None:
        logging.error(f"❌ [{lane_label}] カメラ画像を取得できなかったため、撮影を中止しました。")
        notify_lane_status(
            lane_id,
            "ERROR",
            f"Camera frame missing: {shelf_number}",
            sound_kind="error",
            duration=OPERATION_ERROR_DISPLAY_SECONDS,
        )
        return

    # 新しい写真を旧写真より先に保存できるよう、Drive/AppSheet側の名前も
    # 撮影時刻と短いUUIDを含む一意な名前にします。表示構成や画像列は変わりません。
    capture_timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    capture_id = uuid.uuid4().hex[:8]
    file_name = f"{shelf_number}_{capture_timestamp}_{capture_id}.jpg"

    # パソコン内の一時ファイルにも同じ一意名を使い、同時撮影の上書きを防ぎます。
    local_file_name = file_name
    file_path = os.path.join(BASE_DIR, local_file_name)

    try:
        height, width = frame.shape[:2]
        resized_frame = cv2.resize(frame, (1280, int((1280 / width) * height)))

        is_success, buffer = cv2.imencode(
            ".jpg",
            resized_frame,
            [int(cv2.IMWRITE_JPEG_QUALITY), 85],
        )
        if not is_success:
            logging.error(f"❌ [{lane_label}] JPEG画像への変換に失敗しました。")
            notify_lane_status(
                lane_id,
                "ERROR",
                f"JPEG conversion failed: {shelf_number}",
                sound_kind="error",
                duration=OPERATION_ERROR_DISPLAY_SECONDS,
            )
            return

        with open(file_path, "wb") as image_file:
            image_file.write(buffer)

        notify_lane_status(lane_id, "SENDING", f"Shelf {shelf_number}", duration=0)

        # 通常撮影と自動再送を同時にGoogleへ書き込ませないよう、
        # 送信・キュー整理までを1つの処理として順番に実行します。
        with sync_operation_lock:
            sync_success = _upload_and_sync_core(
                lane_id,
                shelf_number,
                file_path,
                file_name,
                folder_id,
                sheet_name,
            )

            if sync_success:
                # 新しい写真が正常に送信できた場合、同じ棚の古い未送信写真が
                # 後から再送されて表示を巻き戻さないように整理します。
                _discard_older_pending_for_shelf(lane_id, shelf_number)

                try:
                    os.remove(file_path)
                    logging.info(f"🧹 [ローカル整理] 送信済み画像を削除しました: {local_file_name}")
                except OSError as e:
                    logging.warning(f"⚠️ 送信済み画像を削除できませんでした: {e}")

                notify_lane_status(
                    lane_id,
                    "SUCCESS",
                    f"Uploaded: {shelf_number}",
                    sound_kind="success",
                )
            else:
                pending_saved = save_pending_upload(
                    lane_id,
                    shelf_number,
                    file_path,
                    file_name,
                    folder_id,
                    sheet_name,
                    "Google Driveまたはスプレッドシートへの送信に失敗",
                )
                if pending_saved:
                    notify_lane_status(
                        lane_id,
                        "PENDING",
                        f"Saved locally: {shelf_number}",
                        sound_kind="pending",
                        duration=OPERATION_ERROR_DISPLAY_SECONDS,
                    )
                else:
                    logging.error(
                        f"🚨 写真は削除していません。手動で保全してください: {file_path}"
                    )
                    notify_lane_status(
                        lane_id,
                        "ERROR",
                        f"Manual recovery: {shelf_number}",
                        sound_kind="error",
                        duration=OPERATION_ERROR_DISPLAY_SECONDS,
                    )

    except Exception as e:
        logging.error(f"❌ [{lane_label}] 撮影処理中にエラーが発生しました: {e}")
        pending_saved = False
        if os.path.exists(file_path):
            with sync_operation_lock:
                pending_saved = save_pending_upload(
                    lane_id,
                    shelf_number,
                    file_path,
                    file_name,
                    folder_id,
                    sheet_name,
                    str(e),
                )

        if pending_saved:
            notify_lane_status(
                lane_id,
                "PENDING",
                f"Saved locally: {shelf_number}",
                sound_kind="pending",
                duration=OPERATION_ERROR_DISPLAY_SECONDS,
            )
        else:
            if os.path.exists(file_path):
                logging.error(
                    f"🚨 写真は削除していません。手動で保全してください: {file_path}"
                )
            notify_lane_status(
                lane_id,
                "ERROR",
                f"Capture failed: {shelf_number}",
                sound_kind="error",
                duration=OPERATION_ERROR_DISPLAY_SECONDS,
            )

def handle_f12_async():
    try:
        active_window = gw.getActiveWindow()
        if not active_window: return
        title = active_window.title
        current_time = time.time()
        
        # 3号台車（レーン1）
        if LANE1_WINDOW_TITLE in title:
            if not is_target_screen(active_window): return 
            with state_lock:
                if state["lane1_f12_count"] == 0:
                    if (current_time - state["lane1_last_time"]) < COOLDOWN_SECONDS: return
                    logging.info("[3号レーン] 🟢 1回目(呼び出し)検知！棚番号を一時記憶します...")
                    ocr_shelf = extract_shelf_number(active_window)
                    is_valid, normalized_shelf, validation_error = validate_shelf_number(ocr_shelf)
                    if not is_valid:
                        state["lane1_f12_count"] = 0
                        state["lane1_shelf"] = "未取得"
                        state["lane1_last_time"] = current_time
                        notify_shelf_validation_error("3号レーン", ocr_shelf, validation_error)
                        return
                    state["lane1_shelf"] = normalized_shelf
                    state["lane1_f12_count"] = 1
                    state["lane1_last_time"] = current_time
                    set_lane_status("3号", "WAIT", f"Shelf {normalized_shelf}", duration=0)
                else:
                    if (current_time - state["lane1_last_time"]) < LOCKOUT_SECONDS:
                        remaining = int(LOCKOUT_SECONDS - (current_time - state["lane1_last_time"]))
                        logging.warning(f"[3号レーン] ⏳ 作業中ロック: 1回目から3分経過していません（残り約{remaining}秒）。誤操作とみなし撮影をスキップします。")
                        return
                    saved_shelf = state["lane1_shelf"]
                    is_valid, normalized_shelf, validation_error = validate_shelf_number(saved_shelf)
                    state["lane1_f12_count"] = 0
                    state["lane1_shelf"] = "未取得"
                    state["lane1_last_time"] = current_time
                    if not is_valid:
                        notify_shelf_validation_error("3号レーン", saved_shelf, validation_error)
                        return
                    frame_copy = latest_frame1.copy() if latest_frame1 is not None else None
                    set_lane_status("3号", "CAPTURE", f"Shelf {normalized_shelf}", duration=0)
                    threading.Thread(target=capture_process, args=("Lane1", "3号", frame_copy, normalized_shelf, DRIVE_FOLDER_ID_LANE1, SHEET_NAME_LANE1)).start()
                    
        # 4号台車（レーン2）
        elif LANE2_WINDOW_TITLE in title:
            if not is_target_screen(active_window): return
            with state_lock:
                if state["lane2_f12_count"] == 0:
                    if (current_time - state["lane2_last_time"]) < COOLDOWN_SECONDS: return
                    logging.info("[4号レーン] 🟢 1回目(呼び出し)検知！棚番号を一時記憶します...")
                    ocr_shelf = extract_shelf_number(active_window)
                    is_valid, normalized_shelf, validation_error = validate_shelf_number(ocr_shelf)
                    if not is_valid:
                        state["lane2_f12_count"] = 0
                        state["lane2_shelf"] = "未取得"
                        state["lane2_last_time"] = current_time
                        notify_shelf_validation_error("4号レーン", ocr_shelf, validation_error)
                        return
                    state["lane2_shelf"] = normalized_shelf
                    state["lane2_f12_count"] = 1
                    state["lane2_last_time"] = current_time
                    set_lane_status("4号", "WAIT", f"Shelf {normalized_shelf}", duration=0)
                else:
                    if (current_time - state["lane2_last_time"]) < LOCKOUT_SECONDS:
                        remaining = int(LOCKOUT_SECONDS - (current_time - state["lane2_last_time"]))
                        logging.warning(f"[4号レーン] ⏳ 作業中ロック: 1回目から3分経過していません（残り約{remaining}秒）。誤操作とみなし撮影をスキップします。")
                        return
                    saved_shelf = state["lane2_shelf"]
                    is_valid, normalized_shelf, validation_error = validate_shelf_number(saved_shelf)
                    state["lane2_f12_count"] = 0
                    state["lane2_shelf"] = "未取得"
                    state["lane2_last_time"] = current_time
                    if not is_valid:
                        notify_shelf_validation_error("4号レーン", saved_shelf, validation_error)
                        return
                    frame_copy = latest_frame2.copy() if latest_frame2 is not None else None
                    set_lane_status("4号", "CAPTURE", f"Shelf {normalized_shelf}", duration=0)
                    threading.Thread(target=capture_process, args=("Lane2", "4号", frame_copy, normalized_shelf, DRIVE_FOLDER_ID_LANE2, SHEET_NAME_LANE2)).start()
    except Exception as e:
        logging.error(f"F12処理エラー: {e}")

def on_f12(): 
    # 💡 チャタリング（連打）防止処理
    global state
    current_time = time.time()
    with state_lock:
        if current_time - state.get("last_key_press", 0) < DEBOUNCE_SECONDS:
            return 
        state["last_key_press"] = current_time
        
    threading.Thread(target=handle_f12_async).start()

keyboard.add_hotkey('f12', on_f12)

logging.info("==============================================")
logging.info(" 🚀 残材管理システム（改善10.1・緑文字OCR強化版）起動完了")
logging.info("==============================================")
logging.info(f"📝 ログ保存先: {LOG_FILE}（{LOG_RETENTION_DAYS}日分を保持）")
logging.info(f"🕶️ カメラ画面表示: {'ON' if SHOW_CAMERA_WINDOWS else 'OFF（バックグラウンド）'}")

retry_thread = threading.Thread(
    target=pending_retry_worker,
    name='pending-upload-retry',
    daemon=True,
)
retry_thread.start()

status_thread = threading.Thread(
    target=runtime_status_worker,
    name='runtime-heartbeat',
    daemon=True,
)
status_thread.start()

# ==========================================
# 📷 カメラ取得ループ処理（改善10：安全終了・画面非表示対応）
# ==========================================
try:
    while True:
        try:
            if _stop_requested():
                logging.info('🛑 終了要求を受信しました。残材管理システムを正常終了します。')
                break

            ret1, frame1 = cap1.read()
            now_iso = datetime.now().isoformat(timespec='seconds')
            if ret1:
                latest_frame1 = frame1
                with runtime_lock:
                    runtime_camera_state["lane1_connected"] = True
                    runtime_camera_state["lane1_last_frame_at"] = now_iso
                if SHOW_CAMERA_WINDOWS:
                    cv2.imshow("Lane 1 (3号)", draw_lane_status(frame1, "lane1", "3-GO"))
            else:
                with runtime_lock:
                    runtime_camera_state["lane1_connected"] = False
                time.sleep(0.05)

            ret2, frame2 = cap2.read()
            now_iso = datetime.now().isoformat(timespec='seconds')
            if ret2:
                latest_frame2 = frame2
                with runtime_lock:
                    runtime_camera_state["lane2_connected"] = True
                    runtime_camera_state["lane2_last_frame_at"] = now_iso
                if SHOW_CAMERA_WINDOWS:
                    cv2.imshow("Lane 2 (4号)", draw_lane_status(frame2, "lane2", "4-GO"))
            else:
                with runtime_lock:
                    runtime_camera_state["lane2_connected"] = False
                time.sleep(0.05)

            if SHOW_CAMERA_WINDOWS:
                if cv2.waitKey(33) & 0xFF == ord('q'):
                    break
            else:
                # 非表示時はOpenCV GUI待機を行わず、CPU占有を抑えるため少し待機します。
                time.sleep(0.01)

        except KeyboardInterrupt:
            break
        except Exception as e:
            # .pywでは例外が画面に出ないため、必ずログへ記録して一時待機後に継続します。
            logging.exception(f"❌ カメラ取得ループでエラーが発生しました。1秒後に継続します: {e}")
            time.sleep(1.0)
finally:
    retry_stop_event.set()
    # 終了状態をなるべく即時反映します。
    try:
        status_thread.join(timeout=2.0)
    except Exception:
        pass
    cap1.release()
    cap2.release()
    if SHOW_CAMERA_WINDOWS:
        cv2.destroyAllWindows()

    try:
        if os.path.exists(STOP_REQUEST_FILE):
            os.remove(STOP_REQUEST_FILE)
    except OSError:
        pass

    _release_single_instance_mutex()
    logging.info('👋 残材管理システムを正常終了しました。')
