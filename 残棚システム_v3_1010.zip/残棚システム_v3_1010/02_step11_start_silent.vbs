Option Explicit
Dim shell, fso, baseDir, commandPath
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
baseDir = fso.GetParentFolderName(WScript.ScriptFullName)
commandPath = baseDir & "\02_step11_start.bat"
shell.Run Chr(34) & commandPath & Chr(34), 0, False
