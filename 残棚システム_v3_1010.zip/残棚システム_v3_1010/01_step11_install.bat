@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

set "SOURCE=%~dp0zanza_system_step10_safe_background_OCR10_1.pyw"
set "OUTPUT=%~dp0zanza_system_step11_countdown_popup_manual_capture.pyw"

echo ============================================================
echo  残材管理システム 改善11 再生成
echo  ・2回目F12で3秒カウントダウン
echo  ・撮影完了ポップアップ
echo  ・Ctrl+Shift+F11で手動撮影
echo ============================================================
echo.

if not exist "%SOURCE%" (
  echo [ERROR] 元ファイルが見つかりません。
  echo %SOURCE%
  echo.
  echo ZIPをもう一度展開してください。
  pause
  exit /b 1
)

echo 元ファイルは、このパッケージに同梱されています。
echo 会社PCで現在使用中の元ファイルに実際のGoogle設定や独自修正がある場合は、
echo そのファイルを同じ名前で上書きしてから、このBATを実行してください。
echo.

where py.exe >nul 2>&1
if not errorlevel 1 goto USE_PY

where python.exe >nul 2>&1
if not errorlevel 1 goto USE_PYTHON

echo [ERROR] Pythonを見つけられませんでした。
echo PythonがインストールされているPCで実行してください。
pause
exit /b 1

:USE_PY
py -3 "%~dp0apply_step11_patch.py" --source "%SOURCE%" --output "%OUTPUT%"
set "RESULT=%ERRORLEVEL%"
goto AFTER_PATCH

:USE_PYTHON
python "%~dp0apply_step11_patch.py" --source "%SOURCE%" --output "%OUTPUT%"
set "RESULT=%ERRORLEVEL%"
goto AFTER_PATCH

:AFTER_PATCH
if not "%RESULT%"=="0" goto FAILED

echo.
echo [OK] 改善11ファイルを再生成しました。
echo 生成ファイル:
echo   zanza_system_step11_countdown_popup_manual_capture.pyw
echo.
echo Google設定が未入力の場合は、09_step11_set_google_settings.bat を実行してください。
echo その後、07_step11_environment_check.bat で確認してください。
echo.
pause
exit /b 0

:FAILED
echo.
echo [ERROR] 改善11ファイルの再生成に失敗しました。
echo 画面上のエラー内容と step11_install_result.txt を確認してください。
echo.
pause
exit /b %RESULT%
