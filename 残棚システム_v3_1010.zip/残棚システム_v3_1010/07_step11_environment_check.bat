@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

where py.exe >nul 2>&1
if not errorlevel 1 (
  py -3 "%~dp0step11_environment_check.py"
  goto DONE
)

where python.exe >nul 2>&1
if not errorlevel 1 (
  python "%~dp0step11_environment_check.py"
  goto DONE
)

echo [ERROR] Pythonを見つけられませんでした。

:DONE
echo.
pause
exit /b %ERRORLEVEL%
